import dotenv from "dotenv";
dotenv.config({ path: "config.env" });

const developers: string[] = process.env.DEVELOPERS
    ? process.env.DEVELOPERS.split(',').map(s => s.trim()).filter(Boolean)
    : [];

interface Config {
    developers: string[];
    status_name: string;
    status: string;
    discord?: string;
    dashboard: string;
    server?: string;
    prefix: string;
    webhooks: {
        logs?: string;
        maintenance_logs?: string;
        ratelimit_logs?: string;
        blacklist?: string;
        report?: string;
        contact?: string;
        bugs?: string;
        premium?: string;
        errors?: string;
        auth?: string;
        joinsPublic?: string;
        joinsPrivate?: string;
        leavesPublic?: string;
        leavesPrivate?: string;
    };
    maintenance: string;
    maintenance_threshold: string;
    invite_link?: string;
    seo: {
        enabled: string;
        title: string;
        description: string;
    };
    youtube_channel: string;
}

const config: Config = {
    developers: developers,
    status_name: "G.help",
    status: "online",
    discord: process.env.DISCORD,
    dashboard: "true",
    server: process.env.SERVER,
    prefix: "G.",
    webhooks: {
        logs: process.env.WEBHOOKS_LOGS,
        maintenance_logs: process.env.WEBHOOKS_MAINTENANCE_LOGS,
        ratelimit_logs: process.env.WEBHOOKS_RATELIMIT_LOGS,
        blacklist: process.env.WEBHOOKS_BLACKLIST,
        report: process.env.WEBHOOKS_REPORT,
        contact: process.env.WEBHOOKS_CONTACT,
        bugs: process.env.WEBHOOKS_BUGS,
        premium: process.env.WEBHOOKS_PREMIUM,
        errors: process.env.WEBHOOKS_ERRORS,
        auth: process.env.WEBHOOKS_AUTH,
        joinsPublic: process.env.WEBHOOKS_JOINS_PUBLIC,
        joinsPrivate: process.env.WEBHOOKS_JOINS_PRIVATE,
        leavesPublic: process.env.WEBHOOKS_LEAVES_PUBLIC,
        leavesPrivate: process.env.WEBHOOKS_LEAVES_PRIVATE
    },
    maintenance: "false",
    maintenance_threshold: "3",
    invite_link: process.env.INVITE_LINK,
    seo: {
        enabled: "false",
        title: "GOD",
        description: "Welcome"
    },
    youtube_channel: "https://youtube.com/@AbdullahZughbi?si=bACt2yqH9hBxAv8G"
};

export default config;
