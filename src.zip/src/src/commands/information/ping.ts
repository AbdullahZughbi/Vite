import os from "os";
import process from "process";
import Command from "../../structures/Command";
import {
    Message,
    TextChannel,
    Status,
    EmbedBuilder,
    ButtonBuilder,
    ActionRowBuilder,
    ButtonStyle
} from "discord.js";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/commands/information/ping";

export default class extends Command {
    constructor(...args: [any, any]) {
        super(...args, {
            name: "ping",
            description: "Ping pong",
            category: "Information",
            cooldown: 5,
        });
    }

    public async run(
        message: Message,
        args: string[],
        _language: supportLanguages
    ): Promise<void> {
        const language = languages[_language];
        
        if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");
            
            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);
            
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
            
            await (message.channel as TextChannel).send({
                embeds: [embed],
                components: [row]
            }).catch(() => {});
            return;
        }
        
        const msg = await (message.channel as TextChannel).send({
            content: `${language.pinging}`
        }).catch(() => null);
        if (!msg) return;
        
        const latency = Date.now() - message.createdTimestamp;

        let dbLatency: string | number;
        try {
            const start = Date.now();
            await this.client.sequelize.query("SELECT 1");
            dbLatency = Date.now() - start;
        } catch {
            dbLatency = `${language.N_A}`;
        }

        let formattedSize = `${language.N_A}`;
        try {
            const [results] = await this.client.sequelize.query(`
                SELECT 
                    SUM(data_length + index_length) / 1024 / 1024 AS "Size (MB)"
                FROM information_schema.tables
                WHERE table_schema = DATABASE();
            `) as unknown as any[];

            if (results.length > 0 && results[0]["Size (MB)"] !== null) {
                formattedSize = formatSize(parseFloat(results[0]["Size (MB)"]), language);
            }
        } catch {
            formattedSize = `${language.N_A}`;
        }

        // Get initial CPU usage snapshot
        const startUsage = process.cpuUsage();

        // Wait 1 second to measure CPU usage delta
        await new Promise((res) => setTimeout(res, 1000));

        // Calculate CPU usage over 1 second interval
        const elapsedUsage = process.cpuUsage(startUsage);
        const cpuPercent = ((elapsedUsage.user + elapsedUsage.system) / 1000) / 10; // % CPU

        // Memory usage
        const memoryUsage = process.memoryUsage();
        const memoryFormatted = `${(memoryUsage.rss / 1024 / 1024).toFixed(2)} ${language.size.MB}`;

        let connectionStatus: string;
        switch (this.client.ws.status) {
            case Status.Ready: connectionStatus = `${language.status.Ready}`; break;
            case Status.Connecting: connectionStatus = `${language.status.Connecting}`; break;
            case Status.Reconnecting: connectionStatus = `${language.status.Reconnecting}`; break;
            case Status.Idle: connectionStatus = `${language.status.Idle}`; break;
            case Status.Nearly: connectionStatus = `${language.status.NearlyReady}`; break;
            case Status.Disconnected: connectionStatus = `${language.status.Disconnected}`; break;
            case Status.WaitingForGuilds: connectionStatus = `${language.status.WaitingForGuilds}`; break;
            case Status.Identifying: connectionStatus = `${language.status.Identifying}`; break;
            case Status.Resuming: connectionStatus = `${language.status.Resuming}`; break;
            default: connectionStatus = `${language.status.Unknown}`; break;
        }

        const embed = new EmbedBuilder()
            .setTitle(`${language.message.pong}`)
            .setColor("#050000")
            .addFields(
                {
                    name: `${language.message.status}`,
                    value: `\`${connectionStatus}\``,
                    inline: true
                },
                {
                    name: `${language.message.latency}`,
                    value: `\`${latency}${language.ms}\``,
                    inline: true
                },
                {
                    name: `${language.message.discord_api}`,
                    value: `\`${Math.round(this.client.ws.ping)}${language.ms}\``,
                    inline: true
                },
                {
                    name: `${language.message.database_latency}`,
                    value: `\`${dbLatency}${language.ms}\``,
                    inline: true
                },
                {
                    name: `${language.message.database_size}`,
                    value: `\`${formattedSize}\``,
                    inline: true
                },
                {
                    name: `${language.message.memory_bot}`,
                    value: `\`${memoryFormatted}\``,
                    inline: true
                },
                {
                    name: `${language.message.cpu_usage}`,
                    value: `\`${cpuPercent.toFixed(2)}%\``,
                    inline: true
                }
            )
            .setTimestamp();

        await (msg as Message<true>).edit({
            content: "",
            embeds: [embed]
        }).catch(() => {});
    }
};

function formatSize(sizeMB: number, language: typeof languages[supportLanguages]): string {
    const bytes = sizeMB * 1024 * 1024;
    if (bytes < 1024) return `${bytes.toFixed(0)} ${language.size.Bytes}`;
    const kb = bytes / 1024;
    if (kb < 1024) return `${kb.toFixed(2)} ${language.size.KB}`;
    const mb = kb / 1024;
    if (mb < 1024) return `${mb.toFixed(2)} ${language.size.MB}`;
    const gb = mb / 1024;
    if (gb < 1024) return `${gb.toFixed(2)} ${language.size.GB}`;
    const tb = gb / 1024;
    return `${tb.toFixed(2)} ${language.size.TB}`;
}
