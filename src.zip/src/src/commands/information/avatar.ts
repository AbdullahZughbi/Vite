import Command from "../../structures/Command";
import {
    AttachmentBuilder,
    Message,
    GuildMember,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    TextChannel,
    EmbedBuilder
} from "discord.js";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/commands/information/avatar";

export default class extends Command {
	constructor(...args: [any, any]) {
		super(...args, {
			name: "avatar",
			description: "Avatar a user",
			category: "Information",
			cooldown: 5,
		});
	}

	public async run(
	    message: Message,
        args: string[],
        _language: supportLanguages
	): Promise<void> {
	    const language = languages[_language]
	    
	    if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");
            
            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);
            
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
            
            await (message.channel as TextChannel).send({
                embeds: [embed],
                components: [row]
            }).catch(() => {});
            return;
        }
        
		const avatarUrl = (message.member as GuildMember).user.displayAvatarURL({
		    size: 512
		});

		if (!avatarUrl) {
			await message.reply(`${language.could_not_retrieve}`).catch(() => {});
			return;
		}

		const attachment = new AttachmentBuilder(avatarUrl, { name: "avatar.png" });

		await (message.member as GuildMember).send({
			content: `${language.here}`,
			files: [attachment],
		})
			.then(() => {
				message.reply(`${language.dm_success}`).catch(() => {});
			})
			.catch(() => {
				message.reply(`${language.dm_error}`).catch(() => {});
			});
	}
};
