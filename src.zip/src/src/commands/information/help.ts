import Command from "../../structures/Command";
import {
	EmbedBuilder,
	Message,
	GuildMember,
	Guild,
	TextChannel,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle,
	StringSelectMenuBuilder
} from "discord.js";
import ButtonMenu from "../../data/ButtonMenu";
import ExtendedClient from "../../structures/ExtendedClient";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/commands/information/help";

export default class extends Command {
    constructor(...args: [any, any]) {
        super(...args, {
            name: "help",
            description: "Get the list of available commands",
            category: "Information",
            cooldown: 10,
        });
    }
    
    public async run(
        message: Message,
        args: string[],
        _language: supportLanguages
	): Promise<void> {
	    const language = languages[_language]
	    
	    if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");
            
            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);
            
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
            
            await (message.channel as TextChannel).send({
                embeds: [embed],
                components: [row]
            }).catch(() => {});
            return;
        }
        
        const categories = [...new Set(this.client.commands.map((cmd) => cmd.category).filter((cat) =>
            cat !== "Owner"
        ))];
        
        const embed = new EmbedBuilder()
            .setTitle(`${language.commands_list}`)
            .setDescription(
                categories.map((cat) => `**${cat}**`).join("\n")
            )
            .setFooter({
                text: `${language.requested_by} ${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})`,
                iconURL: (message.member as GuildMember).displayAvatarURL()
            })
            .setColor(`#050000`);
        
        const select = new StringSelectMenuBuilder()
            .setCustomId(`helpMenu-${(message.member as GuildMember).id}`)
            .setPlaceholder(`${language.select_a_category}`)
            .addOptions(categories.map((cat) => {
                return ({
                    label: `${cat}`,
                    value: `${cat.toLowerCase().replace(/ /g, "")}`,
                    description: `${language.get_commands
                        .replace(/{cat}/g, `${cat.toLowerCase()}`)
                    }`,
                });
            }));
        
        const button = new ButtonBuilder()
            .setLabel(`${language.invite}`)
            .setStyle(5)
            .setURL(`${this.client.config.invite_link}`);
        const button2 = new ButtonBuilder()
            .setLabel(`${language.dashboard}`)
            .setStyle(5)
            .setURL(`https://${process.env.DOMAIN}/dashboard`);
        const button3 = new ButtonBuilder()
            .setLabel("Support")
            .setStyle(5)
            .setURL(`${this.client.config.discord}`);
        const button4 = new ButtonBuilder()
            .setLabel(`${language.subscribe_on_youtube}`)
            .setStyle(5)
            .setURL(`${this.client.config.youtube_channel}`);
        
        const row = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(select);
        const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(button, button2, button3);
        const row3 = new ActionRowBuilder<ButtonBuilder>().addComponents(button4);
        
        const msg = await (message.channel as TextChannel).send({
            embeds: [embed],
            components: [row, row2, row3]
        }).catch(() => null);
        
        if (!msg) return;
        
        setTimeout(async () => {
            const disabledSelect = StringSelectMenuBuilder.from(select).setDisabled(true);
            const disabledRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(disabledSelect);
            
            await (msg as Message<true>).edit({
                embeds: [embed],
                components: [disabledRow, row2, row3]
            }).catch(() => {});
        }, 300000);
	}
};
