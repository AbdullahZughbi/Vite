import Command from "../../structures/Command";
import {
	EmbedBuilder,
	Message,
	GuildMember,
	Guild,
	TextChannel,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle,
	PermissionsString
} from "discord.js";
import permissions from "../../assets/json/permissions";
import ExtendedClient from "../../structures/ExtendedClient";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/commands/information/roleinfo";
import getRoleFromOther from "../../utils/discord/getRoleFromOther";

export default class extends Command {
	constructor(...args: [any, any]) {
		super(...args, {
			name: "roleinfo",
			description: "Get information about a role",
			usage: "<role>",
			examples: ["roleinfo @role"],
			category: "Information",
			cooldown: 5
		});
	}
	
	public async run(
        message: Message,
        args: string[],
        _language: supportLanguages
	): Promise<void> {
	    const language = languages[_language]
	    
	    if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");
            
            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);
            
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
            
            await (message.channel as TextChannel).send({
                embeds: [embed],
                components: [row]
            }).catch(() => {});
            return;
        }
        
        const fail = this.client.emoji.fail;
        const role = await getRoleFromOther(message, args[0]);
        
        if (!role) {
            await (message.channel as TextChannel).send({
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({
                            name: `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).user.id})`,
                            iconURL: (message.member as GuildMember).user.displayAvatarURL()
                        })
                        .setTitle(`${fail} ${language.invalid_role}`)
                        .setDescription(`${language.please_valid_role}`)
                        .setColor("#992d22")
                        .setFooter({
                            text: `${language.footer_text
                                .replace(/{usage}/g, `${this.usage}`)
                                .replace(/{examples}/g, `${this.examples.join(", ")}`)
                            }`
                        })
                ]
            }).catch(() => {});
            return;
        }
        
        const rolePermissions = role.permissions.toArray();
        const finalPermissions = [];
        for (const permission of Object.keys(permissions) as (keyof typeof permissions)[]) {
            if (rolePermissions.includes(permission as PermissionsString)) {
                finalPermissions.push(`+ ${permissions[permission]}`);
            } else {
                finalPermissions.push(`- ${permissions[permission]}`);
            }
        }
        
        const embed = new EmbedBuilder()
            .setTitle(`${language.information
                .replace(/{role.name}/g, `${role.name}`)
            }`)
            .addFields(
                {
                    name: `${language.fields.role}`,
                    value: `<@&${role.id}>`,
                    inline: true
                },
                {
                    name: `${language.fields.role_id}`,
                    value: `${role.id}`,
                    inline: true
                },
                {
                    name: `${language.fields.color}`,
                    value: `${role.hexColor}`,
                    inline: true
                },
                {
                    name: `${language.fields.hoisted}`,
                    value: `${role.hoist}`,
                    inline: true
                },
                {
                    name: `${language.fields.mentionable}`,
                    value: `${role.mentionable}`,
                    inline: true
                },
                {
                    name: `${language.fields.position}`,
                    value: `${role.position}`,
                    inline: true
                },
                {
                    name: `${language.fields.managed}`,
                    value: `${role.managed}`,
                    inline: true
                },
                {
                    name: `${language.fields.created_at}`,
                    value: `<t:${Math.floor(role.createdAt.getTime() / 1000)}:f>`,
                    inline: true
                },
                {
                    name: `${language.fields.permissions}`,
                    value: `\`\`\`\n${finalPermissions.join("\n")}\`\`\``,
                    inline: true
                }
            )
            .setColor("#050000")
            .setFooter({
                text: `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})`,
                iconURL: (message.member as GuildMember).displayAvatarURL(),
            });
        
        await (message.channel as TextChannel).send({
            embeds: [embed]
        }).catch(() => {});
	}
};
