import Command from "../../structures/Command";
import {
    AttachmentBuilder,
    Message,
    GuildMember,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    TextChannel,
    EmbedBuilder
} from "discord.js";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/commands/information/news";
import GOD_DB from "../../database/schemas/GOD";
import parseJsonDeep from "../../utils/parseJsonDeep";

export default class extends Command {
	constructor(...args: [any, any]) {
		super(...args, {
			name: "news",
			description: "Show GOD latest news",
			category: "Information",
			cooldown: 5,
		});
	}
	
	public async run(
	    message: Message,
        args: string[],
        _language: supportLanguages
    ): Promise<void> {
        const language = languages[_language]
	    
	    if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");
            
            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);
            
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
            
            await (message.channel as TextChannel).send({
                embeds: [embed],
                components: [row]
            }).catch(() => {});
            return;
        }
        
        const GOD = GOD_DB(this.client.sequelize);
        
        const god = await GOD.findOne({
            where: {
                nameID: "0"
            }
        });
        
        if (!god) {
            (message.channel as TextChannel).send(`${language.not_found}`).catch(() => {});
            return;
        }
        
        god.data = parseJsonDeep(god.data);
        
        if (!god.data.length) {
            (message.channel as TextChannel).send(`${language.not_found}`).catch(() => {});
            return;
        }
        
        const lastElement = god.data[god.data.length - 1];
        
        const embed = new EmbedBuilder()
            .setColor("#050000")
            .setTitle(`${lastElement.name}`)
            .addFields([
                { 
                    name: `${language.date_published}`,
                    value: `<t:${Math.floor(lastElement.timestamp / 1000)}:f>`,
                    inline: true
                },
                 {
                    name: `${language.version}`,
                    value: `${lastElement.version}`,
                    inline: true
                },
                {
                    name: `${language.news}`,
                    value: `${lastElement.news}`,
                    inline: true
                }
            ])
            .setFooter({
                text: `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id}`
            })
            .setTimestamp();
        
        await (message.channel as TextChannel).send({
            embeds: [embed]
        }).catch(() => {});
    }
};
