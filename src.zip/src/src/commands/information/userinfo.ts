import Command from "../../structures/Command";
import {
	EmbedBuilder,
	Message,
	GuildMember,
	Guild,
	TextChannel,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle,
	PermissionsString
} from "discord.js";
import permissions from "../../assets/json/permissions";
import ExtendedClient from "../../structures/ExtendedClient";
import GuildDB, { type supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/commands/information/userinfo";
import getMemberFromOther from "../../utils/discord/getMemberFromOther";

export default class extends Command {
	constructor(...args: [any, any]) {
		super(...args, {
			name: "userinfo",
			description: "Get information about a user",
			category: "Information",
			usage: "[user]",
			examples: [
                "userinfo @user"
			],
			cooldown: 5
		});
	}
	
	public async run(
        message: Message,
        args: string[],
        _language: supportLanguages
    ): Promise<void> {
        const language = languages[_language]
	    
	    if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");
            
            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);
            
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
            
            await (message.channel as TextChannel).send({
                embeds: [embed],
                components: [row]
            }).catch(() => {});
            return;
        }
        
        let member = await getMemberFromOther(message, args[0]);
        if (!member) member = message.member as GuildMember;
        
        const memberPermissions = member.permissions.toArray();
        const finalPermissions: string[] = [];
        
        for (const permission of Object.keys(permissions) as (keyof typeof permissions)[]) {
            if (memberPermissions.includes(permission as PermissionsString)) {
                finalPermissions.push(`+ ${permissions[permission]}`);
            } else {
                finalPermissions.push(`- ${permissions[permission]}`);
            }
        }
        
        const embed = new EmbedBuilder()
            .setTitle(`${language.embed.title
                .replace(/{user.name}/g, `${member.displayName}`)
            }`)
            .addFields(
                {
                    name: `${language.embed.fields.user}`,
                    value: `<@${member.id}>`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.user_id}`,
                    value: `${member.id}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.joined_server_at}`,
                    value: member.joinedAt
                        ? `<t:${Math.floor(member.joinedAt.getTime() / 1000)}:f>`
                        : `${language.embed.fields.joined_server_at_unknown}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.joined_discord_at}`,
                    value: `<t:${Math.floor(member.user.createdAt.getTime() / 1000)}:f>`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.boosting_since.message}`,
                    value: `**${member.premiumSince ? 
                        `${language.embed.fields.boosting_since.yes}` :
                        `${language.embed.fields.boosting_since.not_boosting}`
                    }**`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.permissions}`,
                    value: `\`\`\`\n${finalPermissions.join("\n")}\`\`\``,
                    inline: true
                }
            )
            .setFooter({
                text: `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})`,
                iconURL: (message.member as GuildMember).displayAvatarURL(),
            })
            .setColor("#050000");
        
        (message.channel as TextChannel).send({
            embeds: [embed]
        }).catch(() => {});
    }
};
