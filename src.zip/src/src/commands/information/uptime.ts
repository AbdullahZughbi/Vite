import Command from "../../structures/Command";
import {
	EmbedBuilder,
	Message,
	GuildMember,
	Guild,
	TextChannel,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle,
	PermissionsString
} from "discord.js";
import permissions from "../../assets/json/permissions";
import ExtendedClient from "../../structures/ExtendedClient";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/commands/information/uptime";
import format from "../../utils/format";

export default class extends Command {
	constructor(...args: [any, any]) {
		super(...args, {
			name: "uptime",
			description: "GOD Uptime",
			category: "Information",
			cooldown: 15
		});
	}
	
	public async run(
        message: Message,
        args: string[],
        _language: supportLanguages
	): Promise<void> {
	    const language = languages[_language]
	    
	    if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");
            
            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);
            
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
            
            await (message.channel as TextChannel).send({
                embeds: [embed],
                components: [row]
            }).catch(() => {});
            return;
        }
        
        let uptime = this.client.uptime ?? 0;
        if (Array.isArray(uptime)) {
            uptime = uptime.reduce((max, cur) => Math.max(max, cur), -Infinity);
        }
        
        const duration = format(uptime, _language);
        
        await (message.channel as TextChannel).send(`${language.online
            .replace(/{duration}/g, `${duration}`)
        }`).catch(() => {});
	}
};
