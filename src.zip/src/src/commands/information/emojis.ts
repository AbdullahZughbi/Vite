import Command from "../../structures/Command";
import {
	EmbedBuilder,
	Message,
	GuildMember,
	Guild,
	TextChannel,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle
} from "discord.js";
import ButtonMenu from "../../data/ButtonMenu";
import ExtendedClient from "../../structures/ExtendedClient";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/commands/information/emojis";

export default class extends Command {
	constructor(...args: [any, any]) {
		super(...args, {
			name: "bots",
			description: "List of emojis",
			category: "Information",
			cooldown: 15
		});
	}
	
	public async run(
        message: Message,
        args: string[],
        _language: supportLanguages
	): Promise<void> {
	    const language = languages[_language]
	    
	    if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");
            
            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);
            
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
            
            await (message.channel as TextChannel).send({
                embeds: [embed],
                components: [row]
            }).catch(() => {});
            return;
        }
        
	    const emojis = (message.guild as Guild).emojis.cache.map((e) => {
            return `${e} \`:${e.name}:\``;
        });
        
        if (!emojis.length) {
            (message.channel as TextChannel).send(`${language.not_found}`);
            return;
        }
        
        const embed = new EmbedBuilder()
            .setTitle(`${language.emoji_list}`)
            .setFooter({
                text: `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})`,
                iconURL: (message.member as GuildMember).displayAvatarURL(),
            })
            .setTimestamp()
            .setColor(`#050000`);
        
        if (emojis.length <= 25) {
            const range = emojis.length == 1 ? "[1]" : `[1 - ${emojis.length}]`;
            await (message.channel as TextChannel).send({
                embeds: [
                    embed
                        .setTitle(`${language.emoji_list} ${range}`)
                        .setDescription(emojis.join("\n")),
                ]
            });
        } else {
            new ButtonMenu(
			    _language,
				message.client as ExtendedClient,
				message.channel as TextChannel,
				message.member as GuildMember,
				embed,
				emojis
			);
        }
	}
};
