import Command from "../../structures/Command";
import {
	EmbedBuilder,
	Message,
	GuildMember,
	Guild,
	TextChannel,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle,
	PermissionsString
} from "discord.js";
import permissions from "../../assets/json/permissions";
import ExtendedClient from "../../structures/ExtendedClient";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/commands/information/permissions";
import getMemberFromOther from "../../utils/discord/getMemberFromOther";

export default class extends Command {
	constructor(...args: [any, any]) {
		super(...args, {
			name: "permissions",
			description: "Permissions a user",
			category: "Information",
			usage: "[user]",
			examples: [
                "permissions @user"
			],
			cooldown: 5
		});
	}
	
	public async run(
        message: Message,
        args: string[],
        _language: supportLanguages
	): Promise<void> {
	    const language = languages[_language]
	    
	    if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");
            
            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);
            
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
            
            await (message.channel as TextChannel).send({
                embeds: [embed],
                components: [row]
            }).catch(() => {});
            return;
        }
        
        let member = await getMemberFromOther(message, args[0]);
        if (!member) member = message.member as GuildMember;
        
        const memberPermissions = member.permissions.toArray();
        const finalPermissions: string[] = [];
        
        for (const permission of Object.keys(permissions) as (keyof typeof permissions)[]) {
            if (memberPermissions.includes(permission as PermissionsString)) {
                finalPermissions.push(`+ ${permissions[permission]}`);
            } else {
                finalPermissions.push(`- ${permissions[permission]}`);
            }
        }
        
        const embed = new EmbedBuilder()
            .setTitle(`${language.title
                .replace(/{user}/g, `${member.nickname || member.displayName}`)
            }`)
            .setDescription(`\`\`\`\n${finalPermissions.join("\n")}\`\`\``)
            .setFooter({
                text: `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})`,
                iconURL: (message.member as GuildMember).displayAvatarURL()
            })
            .setTimestamp()
            .setColor(`#050000`);
        
        await (message.channel as TextChannel).send({
            embeds: [embed]
        }).catch(() => {});
	}
};
