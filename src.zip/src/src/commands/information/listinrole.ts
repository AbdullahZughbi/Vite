import Command from "../../structures/Command";
import {
	EmbedBuilder,
	Message,
	GuildMember,
	Guild,
	TextChannel,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle
} from "discord.js";
import ButtonMenu from "../../data/ButtonMenu";
import ExtendedClient from "../../structures/ExtendedClient";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/commands/information/listinrole";
import getRoleFromOther from "../../utils/discord/getRoleFromOther";
import isManagedRole from "../../utils/discord/isManagedRole";
import isEveryoneRole from "../../utils/discord/isEveryoneRole";

export default class extends Command {
	constructor(...args: [any, any]) {
		super(...args, {
			name: "listinrole",
			description: "List of users that are in the specified role",
			category: "Information",
			usage: "<role>",
			examples: ["listinrole @role"],
			cooldown: 15
		});
	}
	
	public async run(
        message: Message,
        args: string[],
        _language: supportLanguages
	): Promise<void> {
	    const language = languages[_language]
	    
	    if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");
            
            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);
            
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
            
            await (message.channel as TextChannel).send({
                embeds: [embed],
                components: [row]
            }).catch(() => {});
            return;
        }
        
        const fail = this.client.emoji.fail;
        const role = await getRoleFromOther(message, args[0]);
        
        if (!role) {
            await (message.channel as TextChannel).send({
                embeds: [
                    new EmbedBuilder()
                        .setAuthor({
                            name: `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).user.id})`,
                            iconURL: (message.member as GuildMember).user.displayAvatarURL()
                        })
                        .setTitle(`${fail} ${language.invalid_role}`)
                        .setDescription(`${language.please_valid_role}`)
                        .setColor("#992d22")
                        .setFooter({
                            text: `${language.footer_text
                                .replace(/{usage}/g, `${this.usage}`)
                                .replace(/{examples}/g, `${this.examples.join(", ")}`)
                            }`
                        })
                ]
            }).catch(() => {});
            return;
        }
        
        if (isManagedRole(role)) {
            await (message.channel as TextChannel).send({
                embeds: [
                    new EmbedBuilder()
                        .setDescription(`${language.role_is_not_valid
                            .replace(/{role.id}/g, `${role.id}`)
                        }`)
                        .setColor(`#050000`),
                ],
            });
            return;
        }
        
        if (isEveryoneRole(role, message.guild as Guild)) {
            await (message.channel as TextChannel).send({
                embeds: [
                    new EmbedBuilder()
                        .setDescription(`${language.everyone_is_not_valid
                            .replace(/{role}/g, `${role}`)
                        }`)
                        .setColor(`#050000`),
                ],
            });
            return;
        }
        
        const members = await (message.guild as Guild).members.fetch();
        const memberArray = members.filter((m) => m.roles.cache.has(role.id));
        const member = memberArray.map(m => `<@${m.id}>\n${m.user.username}\n(${m.id})`);
        
        if (!member.length) {
            await (message.channel as TextChannel).send(`${language.not_found
                .replace(/{role.name}/g, `${role.name}`)
            }`);
        }
        
        const embed = new EmbedBuilder()
            .setTitle(`${language.list_of_users
                .replace(/{role.name}/g, `${role.name}`)
            }`)
            .setFooter({
                text: `${language.requested_by} ${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})`,
                iconURL: (message.member as GuildMember).user.displayAvatarURL(),
            })
            .setColor("#050000");
        
        if (member.length <= 10) {
            const range = member.length == 1 ? "[1]" : `[1 - ${member.length}]`;
            await (message.channel as TextChannel).send({
                embeds: [
                    embed
                        .setTitle(`${language.list_of_users
                            .replace(/{role.name}/g, `${role.name}`)
                        } ${range}`)
                        .setDescription(member.join("\n\n"))
                ]
            });
        } else {
            new ButtonMenu(
			    _language,
				message.client as ExtendedClient,
				message.channel as TextChannel,
				message.member as GuildMember,
				embed,
				member
			);
        }
	}
};
