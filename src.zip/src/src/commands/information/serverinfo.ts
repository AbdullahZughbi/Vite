import Command from "../../structures/Command";
import {
	EmbedBuilder,
	Message,
	GuildMember,
	Guild,
	TextChannel,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle,
	PermissionsString
} from "discord.js";
import permissions from "../../assets/json/permissions";
import ExtendedClient from "../../structures/ExtendedClient";
import GuildDB, { type supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/commands/information/serverinfo";

export default class extends Command {
	constructor(...args: [any, any]) {
		super(...args, {
			name: "serverinfo",
			description: "Get information about a the server",
			category: "Information",
			cooldown: 5
		});
	}
	
	public async run(
        message: Message,
        args: string[],
        _language: supportLanguages
    ): Promise<void> {
        const language = languages[_language]
	    
	    if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");
            
            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);
            
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
            
            await (message.channel as TextChannel).send({
                embeds: [embed],
                components: [row]
            }).catch(() => {});
            return;
        }
        
        const Guildd = GuildDB(this.client.sequelize);
        
        const guildDB = await Guildd.findOne({
            where: {
                guildId: (message.guild as Guild).id,
            },
        });
        
        const guildOwner = await (message.guild as Guild).fetchOwner().catch(() => null);
        
        let verificationLevel;
        if ((message.guild as Guild).verificationLevel === 0) {
            verificationLevel = `${language.verification_level.none}`;
        } else if ((message.guild as Guild).verificationLevel === 1) {
            verificationLevel = `${language.verification_level.low}`;
        } else if ((message.guild as Guild).verificationLevel === 2) {
            verificationLevel = `${language.verification_level.medium}`;
        } else if ((message.guild as Guild).verificationLevel === 3) {
            verificationLevel = `${language.verification_level.high}`;
        } else if ((message.guild as Guild).verificationLevel === 4) {
            verificationLevel = `${language.verification_level.highest}`;
        }
        
        let iconURL;
        if ((message.guild as Guild).icon) {
            iconURL = `https://cdn.discordapp.com/icons/${(message.guild as Guild).id}/${(message.guild as Guild).icon}`;
        } else {
            iconURL = "https://cdn.glitch.com/82fe990a-7942-42e3-9790-39807ccdb9f6%2Ficon-404-dark.png?v=1602427904949";
        }
        
        const memberss = await (message.guild as Guild).members.fetch();
        const allMembers = memberss.size;
        const members = memberss.filter(member => !member.user.bot).size;
        const bots = memberss.filter(member => member.user.bot).size;
        const vanityURL = (message.guild as Guild).vanityURLCode ? `https://discord.gg/${(message.guild as Guild).vanityURLCode}` : `${language.no_vanity_url}`;
        
        
        const embed = new EmbedBuilder()
            .setTitle(`${language.embed.title
                .replace(/{guild.name}/g, `${(message.guild as Guild).name}`)
            }`)
            .addFields([
                {
                    name: `${language.embed.fields.god_premium.message}`,
                    value: `${
                        (guildDB as any).isPremium ?
                            language.embed.fields.god_premium.true :
                            language.embed.fields.god_premium.false
                    }`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.server_name}`,
                    value: `${(message.guild as Guild).name}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.server_id}`,
                    value: `${(message.guild as Guild).id}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.server_owner}`,
                    value: `${guildOwner ?
                        `<@${guildOwner.id}> **${guildOwner.user.username}** (${guildOwner.id})` :
                        `${language.embed.fields.server_owner_unknown}`}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.vanity_url}`,
                    value: `${vanityURL}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.region}`,
                    value: `${(message.guild as Guild).preferredLocale}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.members_humans_bots}`,
                    value: `${allMembers} | ${members} | ${bots}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.verification_level}`,
                    value: `${verificationLevel}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.categories}`,
                    value: `${(message.guild as Guild).channels.cache.filter((c) => c.type === 4).size}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.channels}`,
                    value: `${(message.guild as Guild).channels.cache.size}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.roles}`,
                    value: `${(message.guild as Guild).roles.cache.size}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.boosts_level}`,
                    value: `${(message.guild as Guild).premiumTier}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.number_of_boosts}`,
                    value: `${(message.guild as Guild).premiumSubscriptionCount}`,
                    inline: true
                },
                {
                    name: `${language.embed.fields.created_at}`,
                    value: `<t:${Math.floor((message.guild as Guild).createdAt.getTime() / 1000)}:f>`,
                    inline: true
                },
            ])
            .setThumbnail(`${iconURL}`)
            .setColor(`#050000`)
            .setFooter({
                text: `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})`,
                iconURL: (message.member as GuildMember).displayAvatarURL(),
            });
        
        await (message.channel as TextChannel).send({
            embeds: [embed]
        }).catch(() => {});
    }
};
