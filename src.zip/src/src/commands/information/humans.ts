import Command from "../../structures/Command";
import {
	EmbedBuilder,
	Message,
	GuildMember,
	Guild,
	TextChannel,
	ActionRowBuilder,
	ButtonBuilder,
	ButtonStyle
} from "discord.js";
import ButtonMenu from "../../data/ButtonMenu";
import ExtendedClient from "../../structures/ExtendedClient";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/commands/information/humans";

export default class extends Command {
	constructor(...args: [any, any]) {
		super(...args, {
			name: "humans",
			description: "List of humans",
			category: "Information",
			cooldown: 15
		});
	}
	
	public async run(
        message: Message,
        args: string[],
        _language: supportLanguages
	): Promise<void> {
	    const language = languages[_language]
	    
	    if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");
            
            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);
            
            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
            
            await (message.channel as TextChannel).send({
                embeds: [embed],
                components: [row]
            }).catch(() => {});
            return;
        }
        
	    const members = await (message.guild as Guild).members.fetch();
		const humanArray = members.filter((member: GuildMember) => !member.user.bot);
		const human = humanArray.map(h => `<@${h.id}>\n${h.user.tag}\n(${h.id})`);
		
		if (!human.length) {
		    await (message.channel as TextChannel).send({
		        content: `${language.not_found}`
		    }).catch(() => {});
		    return;
		}
		
		const embed = new EmbedBuilder()
			.setTitle(`${language.list_of_humans}`)
			.setColor("#050000")
			.setFooter({
				text: `${language.requested_by} ${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})`,
				iconURL: (message.member as GuildMember).user.displayAvatarURL()
			});
		
		if (human.length <= 10) {
		    const range = human.length === 1 ? "[1]" : `[1 - ${human.length}]`;
			await (message.channel as TextChannel).send({
				embeds: [
					embed
						.setTitle(`${language.list_of_humans} ${range}`)
						.setDescription(human.join("\n\n"))
				]
			});
		} else {
		    new ButtonMenu(
			    _language,
				message.client as ExtendedClient,
				message.channel as TextChannel,
				message.member as GuildMember,
				embed,
				human
			);
		}
	}
};
