import type { supportLanguages } from "../database/schemas/Guild";
import languages from "../data/languages/data/format";

export default function format(
    duration: number,
    _language: supportLanguages = "English"
): string {
    const language = languages[_language];
    if (!language) {
        throw new Error(`Couldn't find language data for **${_language}**.`);
    }

    const y = Math.floor(duration / 31104000000);
    const mo = Math.floor((duration % 31104000000) / 2592000000);
    const d = Math.floor((duration % 2592000000) / 86400000);
    const h = Math.floor((duration % 86400000) / 3600000);
    const m = Math.floor((duration % 3600000) / 60000);
    const s = Math.floor((duration % 60000) / 1000);

    const yDisplay = y > 0 ? `${y} ${y === 1 ? language.year : language.years}` : "";
    const moDisplay = mo > 0 ? `${mo} ${mo === 1 ? language.month : language.months}` : "";
    const dDisplay = d > 0 ? `${d} ${d === 1 ? language.day : language.days}` : "";
    const hDisplay = h > 0 ? `${h} ${h === 1 ? language.hour : language.hours}` : "";
    const mDisplay = m > 0 ? `${m} ${m === 1 ? language.minute : language.minutes}` : "";
    const sDisplay = s > 0 ? `${s} ${s === 1 ? language.second : language.seconds}` : "";

    const parts = [yDisplay, moDisplay, dDisplay, hDisplay, mDisplay, sDisplay].filter(Boolean);

    return parts.join(", ");
};
