import permissions from "../../assets/json/permissions";
import {
    EmbedBuilder,
    GuildMember,
    Guild,
    Interaction,
    CacheType,
    GuildChannel
} from "discord.js";
import ExtendedClient from "../../structures/ExtendedClient";
import SlashCommand from "../../structures/SlashCommand";
import type {
    supportLanguages
} from "../../database/schemas/Guild";

interface replyOptions {
    defer?: boolean;
    isAlreadyReplied?: boolean;
    ephemeral?: boolean;
}

interface checkPermissionsOptions {
    bypass_roles?: string[];
    bypass_users?: string[];
    bypass_channels?: string[];
    blacklist_roles?: string[];
    blacklist_users?: string[];
    blacklist_channels?: string[];
    reply?: replyOptions;
}

export default async function checkPermissions(
    _language: supportLanguages,
    interaction: Interaction<CacheType>,
    command: SlashCommand,
    options: checkPermissionsOptions = {}
): Promise<{ status: string; message?: string; error?: any }> {
    try {
        if (
            !command ||
            !command.name ||
            !command.other ||
            !interaction ||
            !interaction.client
        ) {
            throw new Error("Invalid parameters: missing command or interaction properties");
        }

        const replyOpts = options.reply || {};
        let isAlreadyReplied = typeof replyOpts.isAlreadyReplied === "boolean" ? replyOpts.isAlreadyReplied : false;
        const defer = typeof replyOpts.defer === "boolean" ? replyOpts.defer : true;
        const ephemeral = typeof replyOpts.ephemeral === "boolean" ? replyOpts.ephemeral : false;

        if (defer && !isAlreadyReplied && interaction.isRepliable()) {
            await interaction.deferReply({ ephemeral });
            isAlreadyReplied = true;
        }

        const bypassRoles = options.bypass_roles || [];
        const bypassUsers = options.bypass_users || [];
        const blacklistRoles = options.blacklist_roles || [];
        const blacklistUsers = options.blacklist_users || [];
        const bypassChannels = options.bypass_channels || [];
        const blacklistChannels = options.blacklist_channels || [];
        const userPermission = command.other.userPermission || [];
        const botPermission = command.other.botPermission || [];

        const owner = await (interaction.guild as Guild).fetchOwner().then(o => o.user);
        const member = interaction.member as GuildMember;
        const user = interaction.user;
        const bot = (interaction.guild as Guild).members.me as GuildMember;
        const channel = interaction.channel as GuildChannel;
        const client = interaction.client as ExtendedClient;
        const success = client.emoji.success;
        const fail = client.emoji.fail;

        // Check blacklists
        if (blacklistUsers.includes(user.id)) {
            const send = await sendReply(interaction, {
                content: `${fail} You are blacklisted from using this command.`
            }, isAlreadyReplied, { ephemeral });

            return send.status === "catch" ? send : { status: "return" };
        }

        if (blacklistRoles.some(roleId => member.roles.cache.has(roleId))) {
            const send = await sendReply(interaction, {
                content: `${fail} Your role is blacklisted from using this command.`
            }, isAlreadyReplied, { ephemeral });

            return send.status === "catch" ? send : { status: "return" };
        }

        if (blacklistChannels.includes(channel.id)) {
            const send = await sendReply(interaction, {
                content: `${fail} This channel is blacklisted for this command.`
            }, isAlreadyReplied, { ephemeral });

            return send.status === "catch" ? send : { status: "return" };
        }

        // Check bot permissions
        if (botPermission.length) {
            const missingPermissions = channel
                .permissionsFor(bot.id)
                ?.missing(botPermission)
                .map((p: keyof typeof permissions | string) => permissions[p as keyof typeof permissions]) || [];
            
            if (missingPermissions.length > 0) {
                const embed = new EmbedBuilder()
                    .setDescription(`${fail} I don't have **${missingPermissions.join(", ")}** permission.\n\n**Need help?**\nhttps://${process.env.DOMAIN}/help/other-permissions`)
                    .setColor("#992d22");

                const send = await sendReply(interaction, { embeds: [embed] }, isAlreadyReplied, { ephemeral });

                return send.status === "catch" ? send : { status: "return" };
            }
        }

        // Check user permissions unless bypassed
        const isBypassed = bypassUsers.includes(user.id) ||
            bypassRoles.some(roleId => member.roles.cache.has(roleId)) ||
            bypassChannels.includes(channel.id);

        if (!isBypassed && userPermission.length) {
            const missingPermissions = channel
                .permissionsFor(member)
                ?.missing(userPermission)
                .map((p: keyof typeof permissions | string) => permissions[p as keyof typeof permissions]) || [];
            
            if (missingPermissions.length > 0) {
                const embed = new EmbedBuilder()
                    .setAuthor({
                        name: `${user.username} (${user.id})`,
                        iconURL: user.displayAvatarURL()
                    })
                    .setDescription(`You don't have **${missingPermissions.join(", ")}** permissions`)
                    .setColor("#050000");

                const send = await sendReply(interaction, { embeds: [embed] }, isAlreadyReplied, { ephemeral });

                return send.status === "catch" ? send : { status: "return" };
            }
        }

        return { status: "ok" };
    } catch (error: any) {
        return {
            status: "catch",
            message: error.message || error.toString(),
            error
        };
    }
};

async function sendReply(
	interaction: Interaction,
	data: any,
	isAlreadyReplied: boolean,
	options_reply: { ephemeral?: boolean } = {}
): Promise<{ status: string; message?: string; error?: any }> {
	try {
		if (
			"reply" in interaction &&
			typeof interaction.reply === "function" &&
			"editReply" in interaction &&
			typeof interaction.editReply === "function"
		) {
			if (isAlreadyReplied) {
				await interaction.editReply(data);
			} else {
				await interaction.reply({ ...data, ...options_reply });
			}

			return { status: "ok" };
		} else {
			return {
				status: "catch",
				message: "This interaction type cannot send a reply.",
				error: new Error("Unsupported interaction type")
			};
		}
	} catch (error: any) {
		return {
			status: "catch",
			message: error?.message || String(error),
			error
		};
	}
}
