import {
	Message,
	GuildMember,
	Guild
} from "discord.js";

export default async function getMemberFromOther(
	message: Message,
	arg: string
): Promise<GuildMember | null> {
	try {
		const members = await (message.guild as Guild).members.fetch();

		const member =
			message.mentions.members?.first() ||
			members.get(arg) ||
			members.find(m => m.user.username.toLowerCase() === arg.toLowerCase() || m.user.id === arg);

		return member ?? null;
	} catch {
		return null;
	}
};
