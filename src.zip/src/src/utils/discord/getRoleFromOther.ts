import {
    Message,
    Role,
    Guild
} from "discord.js";

export default async function getRoleFromOther(
    message: Message,
    arg: string
): Promise<Role | null> {
    try {
        // Check for direct mention first
        const mentionedRole = message.mentions.roles.first();
        if (mentionedRole) return mentionedRole;

        // Fetch all roles from the guild
        const roles = await (message.guild as Guild).roles.fetch();

        // Try to match by ID, name, or arg string
        const role = roles.get(arg) ||
            roles.find((r) => r.name.toLowerCase() === arg.toLowerCase()) ||
            roles.find((r) => r.id === arg);

        return role ?? null;
    } catch {
        return null;
    }
};
