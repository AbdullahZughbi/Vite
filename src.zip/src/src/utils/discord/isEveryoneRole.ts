import {
    Role,
    Guild
} from "discord.js";

/**
 * Checks if the given role is the @everyone role of the guild.
 */
export default function isEveryoneRole(role: Role, guild: Guild): boolean {
	return role.id === guild.id;
};
