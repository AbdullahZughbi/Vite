import { Role } from "discord.js";

/**
 * Checks if the given role is a managed role (e.g. bot-integrated).
 * @param role - The role to check.
 * @returns `true` if the role is managed, `false` otherwise.
 */
export default function isManagedRole(role: Role): boolean {
    return role.managed;
};
