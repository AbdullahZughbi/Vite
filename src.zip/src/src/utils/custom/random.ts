interface RandomOption {
    length?: number;
    string?: string;
    min?: number;
    max?: number;
}

export default class RandoStrings {
    public password(option?: RandomOption): string {
        const length: number = option?.length ?? 12;
        const charset: string = option?.string ?? "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        let retVal: string = "";

        for (let i: number = 0, n: number = charset.length; i < length; ++i) {
            const randomIndex: number = Math.floor(Math.random() * n);
            retVal += charset.charAt(randomIndex);
        }
        return retVal;
    }

    public captcha(option?: RandomOption): string {
        const length: number = option?.length ?? 5;
        const charset: string = option?.string ?? "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        let retVal: string = "";

        for (let i: number = 0, n: number = charset.length; i < length; ++i) {
            const randomIndex: number = Math.floor(Math.random() * n);
            retVal += charset.charAt(randomIndex);
        }
        return retVal;
    }

    public numberGenerator(option: { min: number; max: number }): number {
        const minInput: number | undefined = option.min;
        const maxInput: number | undefined = option.max;

        if (minInput === undefined) {
            throw new Error("NUMBERGENERATOR - You did not specify the minimum value. Confused? Join our discord: https://discord.gg/vaZACzAm5u");
        }
        if (maxInput === undefined) {
            throw new Error("NUMBERGENERATOR - You did not specify the maximum value. Confused? Join our discord: https://discord.gg/vaZACzAm5u");
        }
        if (isNaN(minInput)) {
            throw new Error("NUMBERGENERATOR - Your minimum value is not a number. Confused? Join our discord: https://discord.gg/vaZACzAm5u");
        }
        if (isNaN(maxInput)) {
            throw new Error("NUMBERGENERATOR - Your maximum value is not a number. Confused? Join our discord: https://discord.gg/vaZACzAm5u");
        }
        if (minInput > maxInput) {
            throw new Error("NUMBERGENERATOR - Your minimum value is higher than the maximum value. Confused? Join our discord: https://discord.gg/vaZACzAm5u");
        }

        const min: number = Math.ceil(minInput);
        const max: number = Math.floor(maxInput);
        const result: number = Math.floor(Math.random() * (max - min + 1)) + min;
        return result;
    }
};
