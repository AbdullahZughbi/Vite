const UNIT_MILLISECONDS: Record<string, number> = {
    y: 365 * 24 * 60 * 60 * 1000,
    mo: 30 * 24 * 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    h: 60 * 60 * 1000,
    m: 60 * 1000,
    s: 1000
};

export function parseDuration(str: string): number {
    try {
        let total = 0;
        const regex = /(\d+)(y|mo|d|h|m|s)/g;
        let match;

        while ((match = regex.exec(str)) !== null) {
            const value = parseInt(match[1], 10);
            const unit = match[2];

            if (isNaN(value)) {
                throw new Error(`Invalid number in duration string: ${match[1]}`);
            }
            if (!(unit in UNIT_MILLISECONDS)) {
                throw new Error(`Invalid unit in duration string: ${unit}`);
            }

            total += value * UNIT_MILLISECONDS[unit];
        }

        if (total === 0) {
            throw new Error(`No valid duration parts found in: "${str}"`);
        }

        return total;
    } catch (error) {
        console.error("parseDuration error:", error);
        return NaN;
    }
};
