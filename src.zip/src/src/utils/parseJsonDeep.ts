export default function parseJsonDeep(input: any): any {
    let parsed = input;
    while (typeof parsed === "string") {
        try {
            parsed = JSON.parse(parsed);
        } catch {
            break;
        }
    }
    return parsed;
};
