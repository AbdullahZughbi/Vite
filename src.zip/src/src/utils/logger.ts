import { createLogger, format, transports } from "winston";
const { combine, printf } = format;
import Discord from "discord.js";
import config from "../../config";
const webhookClient: Discord.WebhookClient = new Discord.WebhookClient({
    url: config.webhooks.logs!,
});
const chalk = require("chalk");

const myFormat = printf(({ level, message, label, timestamp }) => {
    webhookClient.send(`${timestamp} [${label}] ${message}`);
    return `${timestamp} [${level}] [${chalk.cyan(label)}] ${message}`;
});

const myCustomLevels = {
    levels: {
        error: 0,
        warn: 1,
        info: 2,
        http: 3,
        verbose: 4,
        debug: 5,
        silly: 6,
    },
};

const logger = createLogger({
    levels: myCustomLevels.levels,
    format: combine(
        format.colorize(),
        format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
        myFormat
    ),
    transports: [
        new transports.Console(),
        new transports.File({ filename: "./dist/src/assets/logs/GOD.log" }),
    ],
});

export default logger;
