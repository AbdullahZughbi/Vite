export default class MemoryStore<T = any> {
    private store: Map<string, { value: T; expiresAt: number }>;

    constructor() {
        this.store = new Map(); // Use a Map to store key-value pairs
    }
  
    public set(key: string, value: T, ttl: number): void {
        const expiresAt = Date.now() + ttl;
        this.store.set(key, { value, expiresAt });

        // Automatically delete the key after the TTL expires
        setTimeout(() => {
            this.store.delete(key);
        }, ttl);
    }

    public get(key: string): T | null {
        const entry = this.store.get(key);
        if (!entry) return null;

        // Check if the entry has expired
        if (Date.now() > entry.expiresAt) {
            this.store.delete(key);
            return null;
        }

        return entry.value;
    }

    public has(key: string): boolean {
        const entry = this.store.get(key);
        if (!entry) return false;

        // Check if the entry has expired
        if (Date.now() > entry.expiresAt) {
            this.store.delete(key);
            return false;
        }

        return true;
    }

    public delete(key: string): void {
        this.store.delete(key);
    }
};
