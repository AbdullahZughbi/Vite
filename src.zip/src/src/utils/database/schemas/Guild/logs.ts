import type { Sequelize, ModelStatic } from "sequelize";
import type { LogEntry } from "../../../../database/schemas/Guild";
import GuildDBFactory from "../../../../database/schemas/Guild";
import parseJsonDeep from "../../../parseJsonDeep";
import { Guild } from "../../../../database/schemas/Guild";

export async function getLogs(sequelize: Sequelize, guildId: string): Promise<LogEntry[]> {
    const GuildDB: ModelStatic<Guild> = GuildDBFactory(sequelize);
    const guild: Guild | null = await GuildDB.findOne({
        where: { guildId }
    });
    if (!guild) return [];

    const logsRaw = guild.logs ?? [];
    const logsParsed = parseJsonDeep(logsRaw);

    if (!Array.isArray(logsParsed)) {
        return [];
    }

    return logsParsed as LogEntry[];
};

export async function getLog(sequelize: Sequelize, guildId: string, index: number): Promise<LogEntry | null> {
    const logs = await getLogs(sequelize, guildId);
    if (index < 0 || index >= logs.length) return null;
    return logs[index];
};

export async function findLogs(sequelize: Sequelize, guildId: string, predicate: (log: LogEntry) => boolean): Promise<LogEntry[]> {
    const logs = await getLogs(sequelize, guildId);
    return logs.filter(predicate);
};

export async function findLog(sequelize: Sequelize, guildId: string, predicate: (log: LogEntry) => boolean): Promise<LogEntry | null> {
    const logs = await getLogs(sequelize, guildId);
    return logs.find(predicate) ?? null;
};

export async function addLog(sequelize: Sequelize, guildId: string, entry: LogEntry): Promise<void> {
    const GuildDB: ModelStatic<Guild> = GuildDBFactory(sequelize);
    const guild: Guild | null = await GuildDB.findOne({ where: { guildId } });
    if (!guild) throw new Error("Guild not found");

    const logsRaw = guild.logs ?? [];
    const logsParsed = parseJsonDeep(logsRaw);

    if (!Array.isArray(logsParsed)) {
        throw new Error("Guild logs corrupted (not an array)");
    }

    const parsedLogs = logsParsed as LogEntry[];
    parsedLogs.push(entry);
    guild.logs = parsedLogs;

    await guild.save();
};

export async function clearLog(sequelize: Sequelize, guildId: string, index: number): Promise<boolean> {
    const GuildDB: ModelStatic<Guild> = GuildDBFactory(sequelize);
    const guild: Guild | null = await GuildDB.findOne({ where: { guildId } });
    if (!guild) throw new Error("Guild not found");

    const logsRaw = guild.logs ?? [];
    const logsParsed = parseJsonDeep(logsRaw);

    if (!Array.isArray(logsParsed)) {
        throw new Error("Guild logs corrupted (not an array)");
    }

    if (index < 0 || index >= logsParsed.length) return false;

    const parsedLogs = logsParsed as LogEntry[];
    parsedLogs.splice(index, 1);
    guild.logs = parsedLogs;

    await guild.save();

    return true;
};

export async function clearLogs(sequelize: Sequelize, guildId: string): Promise<void> {
    const GuildDB: ModelStatic<Guild> = GuildDBFactory(sequelize);
    const guild: Guild | null = await GuildDB.findOne({ where: { guildId } });
    if (!guild) throw new Error("Guild not found");

    guild.logs = [];
    await guild.save();
};
