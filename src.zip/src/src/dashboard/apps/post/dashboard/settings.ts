import {
    Request,
    Response
} from "express";
import React from "react";
import GuildSettings from "../../../../database/schemas/Guild";
import Maintenance from "../../../../database/schemas/maintenance";
import ExtendedClient from "../../../../structures/ExtendedClient";
import type discordUser from "../../../types/User";
import type {
    GuildMember
} from "discord.js";
import format from "../../../../utils/format";
import config from "../../../../../config";

const RATE_LIMIT_TIME = 60 * 1000;

export default async (
    req: Request,
    res: Response,
    client: ExtendedClient,
    GuildSettingsDB: typeof GuildSettings,
    MaintenanceDB: typeof Maintenance,
    jsonconfig: typeof config
) => {
    try {
        if (!req.isAuthenticated()) {
            res.status(401).send({
                status: "unauthorized"
            });
            return;
        }
        
        const guild = client.guilds.cache.get(req.params.guildID);
        if (!guild) {
            res.status(403).send({
                status: "forbidden"
            });
            return;
        }
        
        const members = await guild.members.fetch();
        const member = members.get((req.user as discordUser as any).id);
        if (!member) {
            res.status(403).send({
                status: "forbidden"
            });
            return;
        }
        
        if (!member.permissions.has("ManageGuild")) {
            res.status(403).send({
                status: "permission",
                message: "You don't have MANAGE SERVER permissions."
            });
            return;
        }
        
        if (!(guild.members.me as GuildMember).permissions.has(["ChangeNickname"])) {
            res.status(403).send({
                status: "permission",
                message: "❌ I don't have CHANGE NICKNAME permission."
            });
            return;
        }
        
        const lastSave = client.ratelimits.dashboard.settings.get(guild.id) as number;
        const now = Date.now();

        if (lastSave && now - lastSave < RATE_LIMIT_TIME) {
            const waitMs = RATE_LIMIT_TIME - (now - lastSave);
            const waitTimeFormatted = format(waitMs);
            
            res.status(429).send({
                status: "ratelimit",
                message: `⏳ Please wait ${waitTimeFormatted} before saving settings again.`,
            });
            return;
        }
        client.ratelimits.dashboard.settings.set(guild.id, now);
        setTimeout(() => {
            client.ratelimits.dashboard.settings.delete(guild.id);
        }, RATE_LIMIT_TIME);
        
        const Maintenance = MaintenanceDB(client.sequelize);
        const GuildSettings = GuildSettingsDB(client.sequelize);
        
        const maintenance = await Maintenance.findOne({
            where: {
                maintenance: "maintenance",
            },
        });
        
        if (maintenance && maintenance.toggle === "true") {
            res.status(503).send({
                status: "maintenance",
                message: "🚧 The dashboard is currently under maintenance. Please try again later."
            });
            return;
        }
        
        var storedSettings = await GuildSettings.findOne({
            where: {
                guildId: guild.id,
            },
        });
        if (!storedSettings) {
            storedSettings = await GuildSettings.create({
                guildId: guild.id,
            });
        }
        
        const data = req.body;
        
        let nickname = data.nickname;
        if (!nickname) nickname = (guild.members.me as GuildMember).displayName || (guild.members.me as GuildMember).user.username;
        
        if (nickname.length > 126) {
            res.send({
                status: "nickname_is_above_characters",
                message: "Your nickname is above 126 characters!",
            });
            return;
        }
        
        (guild.members.me as GuildMember).setNickname(nickname);
        
        let prefix = data.prefix;
        
        if (!prefix) prefix = jsonconfig.prefix;
        
        prefix = prefix.replace(/ /g, "");
        
        if (prefix.length > 5) {
            res.send({
                status: "prefix_is_above_characters",
                message: "Your prefix is above 5 characters!",
            });
            return;
        }
        storedSettings.prefix = prefix;
        
        const language = data.language;
        if (language && (GuildSettings.rawAttributes.language.values as any).includes(language)) {
            storedSettings.language = language;
        }
        
        let error: any = false;
        
        await storedSettings.save().catch((err) => {
            error = err;
        });
        
        if (error) {
            console.error(error);
            res.status(500).send({
                status: "error",
                message: `Error: ${error.message || "Unknown server error"}`
            });
            return;
        } else {
            res.send({
                status: "success",
                message: "✅ Your changes have been saved!",
            });
            return;
        }
    } catch (err: any) {
        console.error(err);
        res.status(500).send({
            status: "error",
            message: `Error: ${err.message || "Unknown server error"}`
        });
    }
};
