import {
    Request,
    Response
} from "express";
import React from "react";
import GuildSettings from "../../../../database/schemas/Guild";
import Maintenance from "../../../../database/schemas/maintenance";
import ExtendedClient from "../../../../structures/ExtendedClient";
import type discordUser from "../../../types/User";
import type {
    GuildMember
} from "discord.js";

export default async (
    req: Request,
    res: Response,
    renderTemplate: (
        res: Response,
        req: Request,
        template: string,
        data?: object
    ) => Promise<void>,
    client: ExtendedClient,
    GuildSettingsDB: typeof GuildSettings,
    MaintenanceDB: typeof Maintenance
) => {
    const guild = client.guilds.cache.get(req.params.guildID);
    if (!guild) {
        res.redirect("/dashboard");
        return;
    }
    
    const members = await guild.members.fetch();
    const member = members.get((req.user as discordUser as any).id);
    if (!member) {
        res.redirect("/dashboard");
        return;
    }
    
    if (!member.permissions.has("ManageGuild")) {
        renderTemplate(res, req, "youDontHavePermissions", {
            permsMessage: "MANAGE SERVER",
        });
        return;
    }
    
    if (!(guild.members.me as GuildMember).permissions.has(["ChangeNickname"])) {
        renderTemplate(res, req, "missingPermissions", {
            permsMessage: "CHANGE NICKNAME",
        });
        return;
    }
    
    const Maintenance = MaintenanceDB(client.sequelize);
    const GuildSettings = GuildSettingsDB(client.sequelize);

    const maintenance = await Maintenance.findOne({
        where: {
            maintenance: "maintenance",
        },
    });

    if (maintenance && maintenance.toggle == "true") {
        return renderTemplate(res, req, "maintenance");
    }

    var storedSettings = await GuildSettings.findOne({
        where: {
            guildId: guild.id,
        },
    });
    if (!storedSettings) {
        storedSettings = await GuildSettings.create({
            guildId: guild.id,
        });
    }
    
    renderTemplate(res, req, "./new/mainsettings", {
        guild: guild,
        alert: null,
        nickname: (guild.members.me as GuildMember).displayName || (guild.members.me as GuildMember).user.username,
        settings: storedSettings,
        languages: GuildSettings.rawAttributes.language.values
    });
};
