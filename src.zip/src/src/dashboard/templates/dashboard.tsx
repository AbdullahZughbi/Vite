import React from "react";
import { Helmet } from "react-helmet-async";
import Nav from "./partials/nav";
import type User from "../types/User";
import type Bot from "../types/Bot";
import { PermissionsBitField as Perms } from "discord.js";

interface DashboardProps {
    user?: User;
    bot?: Bot;
    domain?: string;
}

export const Dashboard: React.FC<DashboardProps> = ({
    user,
    bot,
    domain = "",
}) => {
    if (!user?.guilds) return null;

    // Filter guilds where user has ManageGuild permission
    const manageableGuilds = user.guilds.filter((guild) => {
        const perms = new Perms(BigInt(guild.permissions));
        return perms.has(Perms.Flags.ManageGuild);
    });

    // Separate guilds into bot exists and bot not exists
    const guildsWithBot = manageableGuilds.filter(
        (guild) => !!bot?.guilds?.cache?.get(guild.id)
    );
    const guildsWithoutBot = manageableGuilds.filter(
        (guild) => !bot?.guilds?.cache?.get(guild.id)
    );

    // Sort alphabetically by guild name
    const sortByName = (a: any, b: any) =>
        a.name.localeCompare(b.name, undefined, { sensitivity: "base" });

    guildsWithBot.sort(sortByName);
    guildsWithoutBot.sort(sortByName);

    const renderGuild = (guild: any, isBotInGuild: boolean) => {
        const iconurl = guild.icon
            ? `https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png?size=512`
            : "https://cdn.glitch.com/82fe990a-7942-42e3-9790-39807ccdb9f6%2Ficon-404-dark.png?v=1602427904949";

        return (
            <div className="server" key={guild.id}>
                <div className="icon-and-name">
                    <img className="guild-icon" src={iconurl} alt={guild.name} />
                    <p className="guild-name">{guild.name}</p>
                </div>
                <button
                    className={isBotInGuild ? "edit button" : "add button"}
                    id={isBotInGuild ? "editButton" : "addButton"}
                    data-url={isBotInGuild ? `${domain}/dashboard/${guild.id}`: `${domain}/invite?guildID=${guild.id}`}
                >
                    {isBotInGuild ? "Dashboard" : "Add to Discord"}
                </button>
            </div>
        );
    };

    return (
        <div>
            <Helmet>
                <link
                    rel="stylesheet"
                    href={`${domain}/css/templates/dashboard.Q15GWlIcAWFJ5cuKwemai10KYqve85aeAg2aphLrcpuE3IlUPWFcio88CwrCWWVOIrrtT7PraAsWb7tbUlHglg3wlj1J75YsQayR.css`}
                />
            </Helmet>

            <Nav user={user} />

            <div className="container">
                <h1>Select a server</h1>

                <br />
                <br />
                <br />

                <div className="servers">
                    {/* Render guilds where bot exists */}
                    {guildsWithBot.map((guild) => renderGuild(guild, true))}

                    {/* Render guilds where bot does NOT exist */}
                    {guildsWithoutBot.map((guild) => renderGuild(guild, false))}
                </div>
            </div>

            <script
                dangerouslySetInnerHTML={{
                    __html: `
                    document.querySelectorAll(".add.button, .edit.button").forEach((btn) => {
                        btn.addEventListener("click", () => {
                            const url = btn.getAttribute("data-url");
                            if (url) {
                                window.location.href = url;
                            } else {
                                alert("No URL set for this button.");
                            }
                        });
                    });
                    `,
                }}
            />
        </div>
    );
};

export default Dashboard;
