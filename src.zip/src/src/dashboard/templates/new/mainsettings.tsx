import React from "react";
import ExtendedClient from "../../../structures/ExtendedClient";
import {
    Guild,
    GuildMember
} from "discord.js";
import GuildSettings, { supportLanguages } from "../../../database/schemas/Guild";
import Nav from "../partials/nav";
import Sidebar from "../partials/sidebar";
import type { Request } from "express";
import { Helmet } from "react-helmet-async";
import type User from "../../types/User";

interface SettingsProps {
    user: User;
    bot: ExtendedClient;
    req: Request;
    guild: Guild;
    alert: string | null;
    nickname: string;
    settings: typeof GuildSettings;
    domain: string;
    languages: supportLanguages[];
}

const Settings: React.FC<SettingsProps> = ({
    user,
    bot,
    req,
    guild,
    alert,
    nickname,
    settings,
    domain = "",
    languages
}) => {
    return (
        <div>
            <Helmet>
                <link rel="stylesheet" href={`${domain}/css/templates/dashboard/settings.Im52LLr9MlwSFM9Re8U0jJjlovPxqDKq93RAyWu6TFdnAazKFC0rxgSJiIqO5zqWpQl5uYZXaRFjl6Y81X7loRJ9EqDLmSj3XEhl.css`} />
                <meta name="loadBanner" content="true" />
            </Helmet>
            
            <Nav user={user} />
            
            <Sidebar guild={guild} domain={domain} req={req} />
            
            {alert ? (
                <div className="banner">
                    <div className="banner__content">
                        <div className="banner__text">
                            {alert}
                        </div>
                        <button className="banner__close" type="button">
                            <span className="material-icons">close</span>
                        </button>
                    </div>
                </div>
            ) : (
                <div style={{
                    display: "none"
                }} className="banner">
                    <div className="banner__content">
                        <div className="banner__text">
                            {alert}
                        </div>
                        <button className="banner__close" type="button">
                            &times;
                        </button>
                    </div>
                </div>
            )}
            
            <div className="container">
                <div style={{ paddingTop: "100px" }}></div>
                
                <form id="mainsettings">
                    <div className="overviewsTitle">
                        Main Settings
                        <span className="smallDesc"> - Customise GOD Main Settings</span>
                    </div>
                    
                    <br />
                    <br />
                    
                    <h3 style={{ fontFamily: "var(--font2)" }}>Nickname</h3>
                    <p>Change the bot nickname in the server</p>
                    <input
                        className="form-control"
                        type="text"
                        name="nickname"
                        style={{
                            background: "#222",
                            color: "white",
                            border: "none",
                            borderRadius: "10px",
                            width: "80%",
                            padding: "8px",
                        }}
                        placeholder="Nickname"
                        value={
                            nickname ||
                            (guild.members.me as GuildMember).displayName ||
                            (guild.members.me as GuildMember).user.username
                        }
                    />
                    
                    <br />
                    <br />
                    
                    <h3 style={{ fontFamily: "var(--font2)" }}>Prefix</h3>
                    <p>Change the bot prefix</p>
                    <input
                        className="form-control"
                        type="text"
                        name="prefix"
                        style={{
                            background: "#222",
                            color: "white",
                            border: "none",
                            borderRadius: "10px",
                            width: "80%",
                            padding: "8px",
                        }}
                        placeholder="Prefix"
                        value={(settings as any).prefix}
                    />
                    
                    <br />
                    <br />
                    
                    <h3>Language</h3>
                    <p>Select the bot language</p>
                    <select
                        name="language"
                        id="selectLanguage"
                    >
                        {languages.map((language: string) => (
                            <option
                                key={language}
                                value={language}
                                selected={(settings as any).language === language}
                            >
                                {language}
                            </option>
                        ))}
                    </select>
                    
                    <br />
                    <br />
                    <br />
                    <br />
                    <br />
                    
                    <button type="submit" className="save" id="save">
                        Save Changes
                    </button>
                </form>
            </div>
            
            <script
                type="module"
                dangerouslySetInnerHTML={{
                    __html: `
                        import { loadDashboardSettings } from "${domain}/js/templates/dashboard/settings.X71h6Q0ai3C12myB2sBjj5xkIVL41rqYXHbRWi0nnjvGIyXOzdc2ON67gO2SJYPrYBBjofsxDnxBlItiTqemO4TG3xqyPFN3w5ZE.js";
                        
                        loadDashboardSettings();
                    `
                }}
            />
        </div>
    );
};

export default Settings;
