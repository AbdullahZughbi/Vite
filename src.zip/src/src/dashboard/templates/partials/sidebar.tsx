import React from "react";
import type { Guild } from "discord.js";
import type { Request } from "express";

interface SidebarProps {
    guild: Guild;
    domain: string;
    req: Request;
}

const Sidebar: React.FC<SidebarProps> = ({ guild, domain = "", req }) => {
    let iconurl: string;

    if (guild.icon) {
        iconurl = `https://cdn.discordapp.com/icons/${guild.id}/${guild.icon}.png?size=512`;
    } else {
        iconurl = "https://cdn.glitch.com/82fe990a-7942-42e3-9790-39807ccdb9f6%2Ficon-404-dark.png?v=1602427904949";
    }

    // Helper to determine if the current page is active
    const isActive = (path: string) => req.url === path;

    return (
        <>
            <input
                style={{ display: "none" }}
                type="checkbox"
                id="toggle-sidebar"
                className="toggle-sidebar"
            />
            <label htmlFor="toggle-sidebar" className="toggle_sidebar">
                <div className="bar"></div>
                <div className="bar"></div>
                <div className="bar"></div>
            </label>

            <div className="sidebar">
                <ul>
                    <div className="guild">
                        <img className="guild-icon" src={iconurl} alt={guild.name} />
                        <p className="guild-name" style={{ fontSize: 26 }}>{guild.name}</p>
                    </div>

                    <p>Settings</p>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}`) ? "active" : ""} href={`/dashboard/${guild.id}`}>
                            <span><i className="fa fa-gear" /> Bot Settings</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/commands`) ? "active" : ""} href={`/dashboard/${guild.id}/commands`}>
                            <span><i className="fa fa-wrench" /> Commands</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/welcome`) ? "active" : ""} href={`/dashboard/${guild.id}/welcome`}>
                            <span><i className="fa fa-sign-out" /> Welcome</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/autorole`) ? "active" : ""} href={`/dashboard/${guild.id}/autorole`}>
                            <span><i className="fa fa-user-plus" /> Auto Role</span>
                        </a>
                    </li>

                    <p>Moderation</p>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/automod`) ? "active" : ""} href={`/dashboard/${guild.id}/automod`}>
                            <span><i className="fa fa-shield" /> Auto Mod</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/altdetector`) ? "active" : ""} href={`/dashboard/${guild.id}/altdetector`}>
                            <span><i className="fa fa-address-card" /> Alt Detector</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/logging`) ? "active" : ""} href={`/dashboard/${guild.id}/logging`}>
                            <span><i className="fa fa-book" /> Logging</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/members`) ? "active" : ""} href={`/dashboard/${guild.id}/members`}>
                            <span><i className="fa fa-users" /> Members</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/moderation`) ? "active" : ""} href={`/dashboard/${guild.id}/moderation`}>
                            <span><i className="fa fa-legal" /> Moderation</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/verification`) ? "active" : ""} href={`/dashboard/${guild.id}/verification`}>
                            <span><i className="fa fa-lock" /> Verification</span>
                        </a>
                    </li>

                    <p>Utilities</p>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/counting`) ? "active" : ""} href={`/dashboard/${guild.id}/counting`}>
                            <span><i className="fa fa-comment-alt" /> Counting</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/reactionroles`) ? "active" : ""} href={`/dashboard/${guild.id}/reactionroles`}>
                            <span><i className="fa fa-support" /> Reaction Roles</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/levels`) ? "active" : ""} href={`/dashboard/${guild.id}/levels`}>
                            <span><i className="fa fa-signal" /> Levels</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/embeds`) ? "active" : ""} href={`/dashboard/${guild.id}/embeds`}>
                            <span><i className="fa fa-image" /> Embeds</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/tickets`) ? "active" : ""} href={`/dashboard/${guild.id}/tickets`}>
                            <span><i className="fa fa-ticket" /> Tickets</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/applications`) ? "active" : ""} href={`/dashboard/${guild.id}/applications`}>
                            <span><i className="fa fa-file-text" /> Applications</span>
                        </a>
                    </li>

                    <p>Channels</p>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/suggestions`) ? "active" : ""} href={`/dashboard/${guild.id}/suggestions`}>
                            <span><i className="fa fa-lightbulb-o" /> Suggestions</span>
                        </a>
                    </li>
                    <li>
                        <a className={isActive(`/dashboard/${guild.id}/reports`) ? "active" : ""} href={`/dashboard/${guild.id}/reports`}>
                            <span><i className="fa fa-exclamation-triangle" /> Server Reports</span>
                        </a>
                    </li>
                </ul>
            </div>
        </>
    );
};

export default Sidebar;
