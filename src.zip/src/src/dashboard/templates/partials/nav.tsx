import React from "react";
import type User from "../../types/User";


interface NavProps {
    user?: User | null;
    domain?: string;
}

const Nav: React.FC<NavProps> = ({ user, domain = "" }) => {
    const avatar = user?.avatar
        ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=128`
        : "https://cdn.glitch.com/82fe990a-7942-42e3-9790-39807ccdb9f6%2Ficon-404.png?v=1602412158188";

    return (
        <>
            <div className="nav-container">
                <div className="header__nav_bar">
                    <div className="toggle_menu" id="toggle_menu">
                        <div className="line line1"></div>
                        <div className="line line2"></div>
                        <div className="line line3"></div>
                    </div>

                    <ul className="nav-list">
                        {user ? (
                            <li className="nav-list-item avatar-wrap">
                                <a className="avatar-container" id="dropdownHead">
                                    <img className="user-avatar" src={avatar} alt="User avatar" />
                                    <span className="user-name">{user.username}</span>
                                </a>
                            </li>
                        ) : (
                            <li className="nav-list-item">
                                <a href="/login" className="nav-link">Login</a>
                            </li>
                        )}
                        <li className="nav-list-item"><a href="/" className="nav-link">Home</a></li>
                        <li className="nav-list-item"><a href="/support" className="nav-link">Support</a></li>
                    </ul>
                </div>
            </div>

            <div className="blur" id="body-blur"></div>

            <ul className="dropdown" id="dropdown">
                <li className="cross-container">
                    <span className="cross" id="closeDropdown">&times;</span>
                </li>
                <li className="dropdown-li">
                    <a className="logout" href={`${domain}/logout`}>
                        <i className="fas fa-sign-out-alt"></i> Logout
                    </a>
                </li>
            </ul>

            <script
                type="module"
                dangerouslySetInnerHTML={{
                    __html: `
                        import { loadToggleMenu } from "${domain}/js/script/nav.Tzc3Ytk9iWkmsTgpqYlgEiyLsf7PCk4QAdTIeKgscuiQULrJB5jU9vRybsYARgNfTmMCO14Q9QUzOStJB3NrtHr99pfrH0P2TxY5.js";
                        loadToggleMenu();
                    `,
                }}
            ></script>
        </>
    );
};

export default Nav;
