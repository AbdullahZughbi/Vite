import React from "react";
import { Helmet } from "react-helmet-async";
import Nav from "./partials/nav";
import type User from "../types/User";
import type Bot from "../types/Bot";


interface IndexProps {
    user?: User;
    bot?: Bot;
    domain?: string;
}

export const Index: React.FC<IndexProps> = ({ user, bot, domain = "" }) => {
    return (
        <div>
            <Helmet>
                <link
                    rel="stylesheet"
                    href={`${domain}/css/templates/index.mndZQCuWChzJwaoxhInpUogcbkLp7QGyE0q8iIjZ0GZVN9ljsXEp9SEfOj7FE1oZXwqzmmTjqAjh3S3psxwQOQi1CjxbKC6Q3hSq.css`}
                />
            </Helmet>
            
            <Nav user={user} />
            
            <div className="container">
                <div style={{ paddingTop: "60px" }} />
                
                <h1>Welcome {user ? user.username : "!"}</h1>
                
                <h2>
                    Serving{" "}
                    {bot?.guilds.cache.reduce((a, g) => a + (g.memberCount || 0), 0)} members
                </h2>
                <h2>{bot?.guilds.cache.size} servers</h2>
                
                <br />
                <br />
                <br />
                <br />
                <br />
                
                <button className="button" id="addToDiscord">
                    <span>Add to Discord</span>
                </button>
                
                <button className="button" id="_dashboard">
                    <span>Dashboard</span>
                </button>
            </div>
            
            <script
                dangerouslySetInnerHTML={{
                    __html: `
                        const inviteBtn = document.getElementById("addToDiscord");
                        const dashBtn = document.getElementById("_dashboard");
                        inviteBtn?.addEventListener("click", () => {
                            window.location.href = "/invite";
                        });
                        dashBtn?.addEventListener("click", () => {
                            window.location.href = "/dashboard";
                        });
                    `,
                }}
            />
        </div>
    );
};

export default Index;
