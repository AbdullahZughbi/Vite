export function loadBanner() {
    const banner = document.querySelector<HTMLUListElement>(".banner");
    if (!banner) throw new Error("loadBanner: '.banner' element not found");

    const bannerClose = document.querySelector<HTMLUListElement>(".banner__close");
    if (!bannerClose) throw new Error("loadBanner: '.banner__close' element not found");

    // const bannerText = document.querySelector<HTMLUListElement>(".banner__text");
    // if (bannerText) throw new Error("loadBanner: '.banner__text' element not found");

    bannerClose.addEventListener("click", () => {
        banner.style.display = "none";
    });
};
