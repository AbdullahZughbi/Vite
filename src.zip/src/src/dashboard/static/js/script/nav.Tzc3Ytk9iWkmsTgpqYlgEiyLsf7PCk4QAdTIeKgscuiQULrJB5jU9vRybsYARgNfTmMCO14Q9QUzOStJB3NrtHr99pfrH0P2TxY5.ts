export function loadToggleMenu() {
  const dropdown = document.querySelector<HTMLUListElement>('.dropdown');
  const blur = document.querySelector<HTMLDivElement>('.blur');
  const avatarContainer = document.querySelector<HTMLAnchorElement>('.avatar-container');
  const closeDropdown = document.getElementById('closeDropdown');
  const navList = document.querySelector<HTMLUListElement>('.nav-list');
  const toggleMenuBtn = document.getElementById('toggle_menu');

  function toggleMenu() {
    if (navList) {
      navList.classList.toggle('active');
    }
  }

  // Attach toggleMenu listener to toggle button by ID
  if (toggleMenuBtn) {
    toggleMenuBtn.addEventListener('click', toggleMenu);
  }

  if (avatarContainer && dropdown && blur) {
    avatarContainer.addEventListener('click', (event) => {
      event.stopPropagation();
      const isVisible = dropdown.classList.contains('dropdown-visible');
      if (!isVisible) {
        dropdown.classList.add('dropdown-visible');
        blur.classList.add('visible');
      } else {
        dropdown.classList.remove('dropdown-visible');
        blur.classList.remove('visible');
      }
    });
  }

  if (closeDropdown && dropdown && blur) {
    closeDropdown.addEventListener('click', () => {
      dropdown.classList.remove('dropdown-visible');
      blur.classList.remove('visible');
    });
  }

  if (blur && dropdown) {
    blur.addEventListener('click', () => {
      dropdown.classList.remove('dropdown-visible');
      blur.classList.remove('visible');
    });
  }

  document.addEventListener('click', (event) => {
    if (dropdown && avatarContainer) {
      const target = event.target as Node;
      if (!dropdown.contains(target) && !avatarContainer.contains(target)) {
        dropdown.classList.remove('dropdown-visible');
        blur?.classList.remove('visible');
      }
    }
  });
}
