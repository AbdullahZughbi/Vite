export function loadDashboardSettings() {
    try {
        $("#selectLanguage").select2({
            dropdownAutoWidth: true,
            width: '100%',
            placeholder: "Select a channel"
        });
        const bannerClose = document.querySelector<HTMLUListElement>(".banner__close");
        if (!bannerClose) throw new Error("loadDashboardSettings: '.banner__close' element not found");

        const bannerText = document.querySelector<HTMLUListElement>(".banner__text");
        if (!bannerText) throw new Error("loadDashboardSettings: '.banner__text' element not found");

        const banner = bannerText.parentElement?.parentElement;
        if (!banner) throw new Error("loadDashboardSettings: banner container not found");

        let saveWarning = false;
        let busy = false;
        let status: string | null = null;

        const mainPageForm = document.getElementById("mainsettings") as HTMLFormElement;
        if (!mainPageForm) throw new Error("loadDashboardSettings: '#mainsettings' form not found");

        const saveButton = document.getElementById("save") as HTMLButtonElement;
        if (!saveButton) throw new Error("loadDashboardSettings: '#save' button not found");

        const getFormData = (form: HTMLFormElement) => {
            const formData = new FormData(form);
            return Object.fromEntries((formData as any).entries());
        };

        let originalFormData = getFormData(mainPageForm);

        const isFormChanged = (): boolean => {
            const currentData = getFormData(mainPageForm);
            for (const key in originalFormData) {
                if (originalFormData[key] !== currentData[key]) {
                    return true;
                }
            }
            return false;
        };

        mainPageForm.addEventListener("input", () => {
            saveWarning = isFormChanged();
        });

        saveButton.addEventListener("click", async (event) => {
            event.preventDefault();

            if (busy) return;

            busy = true;
            saveWarning = false;
            saveButton.disabled = true;

            try {
                const data = getFormData(mainPageForm);
                originalFormData = data;

                const nickname = data.nickname;
                if (nickname && nickname.length > 126) {
                    bannerText.innerText = "Your nickname is above 126 characters!";
                    banner.style.display = "block";
                    busy = false;
                    saveButton.disabled = false;
                    return;
                }

                const prefix = data.prefix;
                if (prefix && prefix.length > 5) {
                    bannerText.innerText = "Your prefix is above 5 characters!";
                    banner.style.display = "block";
                    busy = false;
                    saveButton.disabled = false;
                    return;
                }

                const response = await fetch(window.location.href, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(data),
                });

                const res = await response.json();

                if (res.status === "unauthorized") {
                    busy = false;
                    saveButton.disabled = false;
                    status = "unauthorized";
                    window.location.href = "/login";
                    return;
                } else if (res.status === "forbidden") {
                    busy = false;
                    saveButton.disabled = false;
                    status = "forbidden";
                    window.location.href = "/dashboard";
                    return;
                } else if (res.status === "permission") {
                    bannerText.innerText = res.message;
                    banner.style.display = "block";
                    busy = false;
                    saveButton.disabled = false;
                    status = null;
                    return;
                } else if (res.status === "success") {
                    bannerText.innerText = res.message;
                    banner.style.display = "block";
                    busy = false;
                    saveWarning = false;
                    saveButton.disabled = false;
                    status = null;
                    return;
                } else if (res.status === "error") {
                    console.error(res.message);
                    bannerText.innerText = res.message;
                    banner.style.display = "block";
                    busy = false;
                    saveButton.disabled = false;
                    status = null;
                    return;
                } else if (res.status === "maintenance") {
                    bannerText.innerText = res.message;
                    banner.style.display = "block";
                    busy = false;
                    saveButton.disabled = false;
                    status = null;
                    return;
                } else if (res.status === "ratelimit") {
                    bannerText.innerText = res.message;
                    banner.style.display = "block";
                    busy = false;
                    saveButton.disabled = false;
                    status = null;
                    return;
                } else if (res.status === "nickname_is_above_characters") {
                    bannerText.innerText = res.message;
                    banner.style.display = "block";
                    busy = false;
                    saveButton.disabled = false;
                    status = null;
                    return;
                } else if (res.status === "prefix_is_above_characters") {
                    bannerText.innerText = res.message;
                    banner.style.display = "block";
                    busy = false;
                    saveButton.disabled = false;
                    status = null;
                    return;
                } else {
                    bannerText.innerText = "An unknown error occurred!";
                    banner.style.display = "block";
                    busy = false;
                    saveButton.disabled = false;
                    status = null;
                    return;
                }
            } catch (err) {
                console.error("Save button handler error:", err);
                bannerText.innerText = "Failed to save settings due to an error.";
                banner.style.display = "block";
                busy = false;
                saveButton.disabled = false;
                status = null;
            }
        });

        window.addEventListener("beforeunload", (event) => {
            if (saveWarning) {
                if (status === "unauthorized" || status === "forbidden") return;
                event.preventDefault();
                event.returnValue = "";
            }
        });

        bannerClose.addEventListener("click", () => {
            banner.style.display = "none";
        });
    } catch (err) {
        console.error("loadDashboardSettings initialization error:", err);
        alert(`Error: ${(err as Error).message ?? "An unknown error occurred."}`);
    }
};
