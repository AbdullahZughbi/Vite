import type { Guild, GuildMemberManager } from "discord.js";

export default interface Bot {
  guilds: {
    cache: {
      size: number;
      reduce: (callback: (accumulator: number, guild: Guild) => number, initialValue: number) => number;
      get: (id: string) => Guild | undefined;
    };
  };
};
