export default interface User {
    username?: string;
    avatar?: string | null;
    id?: string;
    guilds?: any[];
    [key: string]: any;
};
