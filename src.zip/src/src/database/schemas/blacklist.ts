import {
    DataTypes,
    Sequelize,
    Model,
    ModelStatic,
    InferAttributes,
    InferCreationAttributes,
    CreationOptional
} from "sequelize";

export class Blacklist extends Model<
    InferAttributes<Blacklist>,
    InferCreationAttributes<Blacklist>
> {
    declare discordId: string | null;
    declare guildId: string | null;
    declare type: string;
    declare isBlacklist: boolean | null;
    declare reason: string | null;
    declare length: Date | null;  // <-- Changed here
};

export default function (sequelize: Sequelize): ModelStatic<Blacklist> {
    const blacklistSchema = sequelize.define("blacklist", {
        discordId: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        guildId: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        type: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        isBlacklist: {
            type: DataTypes.BOOLEAN,
            allowNull: true,
        },
        reason: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        length: {
            type: DataTypes.DATE,
            allowNull: true,
        },
    }, {
        modelName: "Blacklist",
        tableName: "blacklists",
        timestamps: true,
    });

    return blacklistSchema as unknown as ModelStatic<Blacklist>;
};
