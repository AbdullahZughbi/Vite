import {
    DataTypes,
    Sequelize,
    Model,
    ModelStatic,
    InferAttributes,
    InferCreationAttributes,
    CreationOptional
} from "sequelize";

export class Maintenance extends Model<
    InferAttributes<Maintenance>,
    InferCreationAttributes<Maintenance>
> {
    declare maintenance: string | null;
    declare toggle: string | null;
};

export default function (sequelize: Sequelize): ModelStatic<Maintenance> {
    const _Maintenance = sequelize.define('maintenance', {
        maintenance: {
            type: DataTypes.STRING,
            defaultValue: 'maintenance',
        },
        toggle: {
            type: DataTypes.STRING,
            defaultValue: 'false',
        }
    }, {
        modelName: "Maintenance",
        tableName: 'maintenances',
        timestamps: true,
    });

    return _Maintenance as unknown as ModelStatic<Maintenance>;
};
