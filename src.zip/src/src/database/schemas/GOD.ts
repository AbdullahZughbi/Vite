import {
    DataTypes,
    Sequelize,
    Model,
    ModelStatic,
    InferAttributes,
    InferCreationAttributes,
    CreationOptional
} from "sequelize";

interface info {
    timestamp: number;
    version: string;
    name: string;
    news: string;
}

export class GOD extends Model<
    InferAttributes<GOD>,
    InferCreationAttributes<GOD>
> {
    declare nameID: string;
    declare data: info[];
};

export default function (sequelize: Sequelize): ModelStatic<GOD> {
    const GOD_Schema = sequelize.define("god", {
        nameID: {
            type: DataTypes.STRING,
            defaultValue: "0",
            unique: true
        },
        data: {
            type: DataTypes.JSON,
            defaultValue: []
        }
    }, {
        modelName: "GOD",
        tableName: "god",
        timestamps: true,
    });

    return GOD_Schema as unknown as ModelStatic<GOD>;
};
