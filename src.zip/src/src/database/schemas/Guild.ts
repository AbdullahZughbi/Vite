import {
    DataTypes,
    Sequelize,
    Model,
    ModelStatic,
    InferAttributes,
    InferCreationAttributes,
    CreationOptional
} from "sequelize";
import config from "../../../config";

export type supportLanguages = "English";

export interface LogEntry {
    timestamp: number;
    action: string;
    userID?: string;
    userName?: string;
    details?: string;
};

export class Guild extends Model<
    InferAttributes<Guild>,
    InferCreationAttributes<Guild>
> {
    declare guildId: string;
    declare disabledCommands: string[] | null;
    declare prefix: CreationOptional<string>;
    declare isPremium: CreationOptional<boolean>;
    declare premium: {
        redeemedBy: {
            id: string | null;
            username: string | null;
        };
        redeemedAt: Date | null;
        expiresAt: Date | null;
        code: string | null;
        tier: number;
    } | null;
    declare language: CreationOptional<supportLanguages>;

    declare logs: CreationOptional<LogEntry[]>;
};

export default function (sequelize: Sequelize): ModelStatic<Guild> {
    const GuildConfig = sequelize.define("guild", {
        guildId: {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true
        },
        disabledCommands: {
            type: DataTypes.JSON,
            defaultValue: [],
        },
        prefix: {
            type: DataTypes.STRING,
            allowNull: false,
            defaultValue: config.prefix || "G!",
        },
        isPremium: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
            allowNull: false
        },
        premium: {
            type: DataTypes.JSON,
            defaultValue: {
                redeemedBy: {
                    id: null,
                    username: null,
                },
                redeemedAt: null,
                expiresAt: null,
                code: null,
                tier: 0,
            },
        },
        language: {
            type: DataTypes.ENUM("English"),
            defaultValue: "English",
        },
        logs: {
            type: DataTypes.JSON,
            defaultValue: [],
        },
    }, {
        modelName: "Guild",
        tableName: "guilds",
        timestamps: true,
    });

    return GuildConfig as unknown as ModelStatic<Guild>;
};
