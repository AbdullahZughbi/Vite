import SelectMenu from "../../structures/SelectMenu";
import {
    EmbedBuilder,
    SelectMenuInteraction,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    Guild as _Guild,
    MessageActionRowComponentBuilder,
    ComponentType,
    APIMessageComponent,
    StringSelectMenuBuilder
} from "discord.js";
import ExtendedClient from "../../structures/ExtendedClient";
import GuildDB, {
    type supportLanguages,
    Guild as GuildModel
} from "../../database/schemas/Guild";
import languages from "../../data/languages/components/selectMenus/helpMenu";

export default class HelpMenu extends SelectMenu {
    constructor(...args: [ExtendedClient, any]) {
        super(...args, {
            name: "helpMenu-",
        });
    }

    public async run(
        interaction: SelectMenuInteraction,
        _language: supportLanguages,
    ): Promise<void> {
        const language = languages[_language];

        if (!language) {
            const embed = new EmbedBuilder()
                .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                .setColor("#992d22");

            const supportButton = new ButtonBuilder()
                .setLabel("Report it here")
                .setStyle(ButtonStyle.Link)
                .setURL(this.client.config.discord!);

            const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);

            await interaction.update({
                embeds: [embed],
                components: [row],
            }).catch(() => {});
            return;
        }

        // Disable old message's components
        const disabledRows = interaction.message.components.map((componentRow: any) => {
			const disabledComponents = componentRow.components.map((component: any) => {
				if (component.type === ComponentType.Button) {
					const btn = ButtonBuilder.from(component as ButtonBuilder);
					if (btn.data.style === ButtonStyle.Link) return btn;
					return btn.setDisabled(true);
				} else if (component.type === ComponentType.SelectMenu) {
				    return StringSelectMenuBuilder.from(component as StringSelectMenuBuilder).setDisabled(true);
				}
				return component;
			}) as MessageActionRowComponentBuilder[];

			return new ActionRowBuilder<MessageActionRowComponentBuilder>()
				.addComponents(...disabledComponents);
		});

        await interaction.update({
            components: disabledRows,
        });

        const Guild = GuildDB(this.client.sequelize);
        const guildDB = await Guild.findOne({
            where: {
                guildId: (interaction.guild as _Guild).id
            },
        });

        const prefix = (guildDB as GuildModel).prefix;

        const selectedValue = interaction.values?.[0];
        if (!selectedValue) {
            await interaction.followUp({
                content: `${language.category_not_found}`,
                ephemeral: true,
            });
            return;
        }

        const categories = [...new Set(this.client.commands.map(cmd => cmd.category))];
        const category = categories.find(cat =>
            cat.toLowerCase().replace(/ /g, "") === selectedValue
        );

        if (!category) {
            await interaction.followUp({
                content: `${language.category_not_found}`,
                ephemeral: true,
            });
            return;
        }
        
        const reenabledRows = disabledRows.map(row => {
			const reenabledComponents = row.components.map(component => {
				if (component instanceof ButtonBuilder && component.data.style !== ButtonStyle.Link) {
					return ButtonBuilder.from(component).setDisabled(false);
				} else if (component instanceof StringSelectMenuBuilder) {
				    const menu = StringSelectMenuBuilder.from(component).setDisabled(false);
				    const selectedOption = menu.options.find((option) => option.data.value === selectedValue);
				    if (selectedOption) {
				        selectedOption.setDefault(true);
				    }
				    return menu;
				}
				return component;
			});
			return new ActionRowBuilder<MessageActionRowComponentBuilder>().addComponents(...reenabledComponents);
		});

        const embed = EmbedBuilder.from(interaction.message.embeds[0])
            .setTitle(`${category} ${language.commands}`)
            .setDescription(getCommandsByCategory(this.client, selectedValue, prefix));

        await interaction.editReply({
            embeds: [embed],
            components: reenabledRows,
        });
    }
}

function getCommandsByCategory(
    client: ExtendedClient,
    category: string,
    prefix: string
): string {
    return client.commands
        .filter(cmd =>
            cmd.category.toLowerCase().replace(/ /g, "") === category
        )
        .map(cmd =>
            `**${prefix}${cmd.name}**\n${cmd.description}`
        )
        .join("\n\n");
}
