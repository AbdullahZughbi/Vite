import Event from "../../structures/Event";
import MaintenanceDB from "../../database/schemas/maintenance";
import {
    EmbedBuilder,
    ButtonInteraction,
    ModalSubmitInteraction,
    SelectMenuInteraction,
    ChatInputCommandInteraction,
    GuildMember,
    Interaction,
    ApplicationCommandOptionType,
    Guild,
    ButtonBuilder,
    ActionRowBuilder,
    ButtonStyle
} from "discord.js";
import parseJsonDeep from "../../utils/parseJsonDeep";
import GuildDB, {
    supportLanguages
} from "../../database/schemas/Guild";
import languages from "../../data/languages/events/interaction/interactionCreate";

export default class InteractionEvent extends Event {
    public async run(interaction: Interaction): Promise<void> {
        const Maintenance = MaintenanceDB(this.client.sequelize);
        const guild = GuildDB(this.client.sequelize);
        
        const maintenance = await Maintenance.findOne({
            where: {
                maintenance: "maintenance",
            },
        });

        // Only allow developers during maintenance
        if (!this.client.config.developers.includes(interaction.user.id)) {
            if (maintenance && maintenance.toggle === "true") return;
        }
        
        let language: typeof languages[supportLanguages] = languages["English"];
        let _language: supportLanguages = "English";
        if (interaction.guild) {
            let settings = await guild.findOne({
                where: {
                    guildId: (interaction.guild as Guild).id
                }
            });
            if (!settings) {
                settings = await guild.create({
                    guildId: (interaction.guild as Guild).id
                });
            }
            language = languages[settings.language as supportLanguages];
            _language = settings.language as supportLanguages;
            if (!language) {
                if (
                    "reply" in interaction &&
                    typeof interaction.reply === "function"
                ) {
                    const embed = new EmbedBuilder()
                        .setDescription(`Sorry, I couldn't find language data for **${_language}**.`)
                        .setColor("#992d22");
                    
                    const supportButton = new ButtonBuilder()
                        .setLabel("Report it here")
                        .setStyle(ButtonStyle.Link)
                        .setURL(this.client.config.discord!);
                    
                    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
                    
                    await interaction.reply({
                        embeds: [embed],
                        components: [row],
                        ephemeral: false
                    }).catch(() => {});
                    return;
                } else {
                    throw new Error("Unsupported interaction type")
                }
            }
        }

        if (interaction.isButton()) {
            await this.handleButton(
                interaction,
                language,
                _language
            );
        } else if (interaction.isModalSubmit()) {
            await this.handleModal(
                interaction,
                language,
                _language
            );
        } else if (interaction.isSelectMenu()) {
            await this.handleSelectMenu(
                interaction,
                language,
                _language
            );
        } else if (interaction.isCommand() && interaction.isChatInputCommand()) {
            await this.handleSlashCommand(
                interaction,
                language,
                _language
            );
        }
    }

    private async handleButton(
        interaction: ButtonInteraction,
        language: typeof languages[supportLanguages],
        _language: supportLanguages
    ) {
        const id = interaction.customId;

        switch (id) {
            case "first":
            case "previous":
            case "stop":
            case "next":
            case "last":
                return;
            default: {
                let button = this.client.buttons.get(id.replace(interaction.user.id, ""));
                if (!button) {
                    const user = await getMemberFromID(interaction, id.replace(/[a-zA-Z]/g, "").replace(/-/g, ""));
                    const msgo = await interaction.channel!.messages.fetch(id.replace(/[a-zA-Z]/g, "").replace(/-/g, "")).catch(() => undefined);
                    if (msgo) {
                        button = this.client.buttons.get(id.replace(/[0-9]/g, ""));
                    } else {
                        if (!this.client.buttons.get(id.replace(/[0-9]/g, "")) || !this.client.buttons.get(id.replace(/[0-9]/g, "").replace(/-/g, ""))) {
                            await interaction.reply({
                                content: `${language.error}`,
                                ephemeral: false
                            });
                            return;
                        }
                        if (user) {
                            await interaction.reply({
                                content: `${language.not_allowed_button
                                    .replace(/{user.id}/g, `${user.id}`)
                                }`,
                                ephemeral: true
                            });
                            return;
                        } else {
                            return interaction.reply({
                                content: `${language.error}`,
                                ephemeral: false
                            });
                            return;
                        }
                    }
                }

                if (!this.client.buttons.get(id.replace(/[0-9]/g, ""))) {
                    await interaction.reply({
                        content: `${language.error}`,
                        ephemeral: false
                    });
                    return;
                }
                
                if (!button) {
                    await interaction.reply({
                        content: `${language.error}`,
                        ephemeral: false
                    });
                    return;
                }

                try {
                    await button.run(interaction, _language);
                } catch (error) {
                    this.client.emit("buttonError", error, interaction, _language);
                }
            }
        }
    }

    private async handleModal(
        interaction: ModalSubmitInteraction,
        language: typeof languages[supportLanguages],
        _language: supportLanguages
    ) {
        const modal = this.client.modals.get(interaction.customId);
        if (!modal) {
            interaction.reply({
                content: `${language.error}`,
                ephemeral: false
            });
            return;
        }

        try {
            await modal.run(interaction, _language);
        } catch (error) {
            this.client.emit("modalError", error, interaction);
        }
    }

    private async handleSelectMenu(
        interaction: SelectMenuInteraction,
        language: typeof languages[supportLanguages],
        _language: supportLanguages
    ) {
        const idWithoutUser = interaction.customId.replace(interaction.user.id, "");
        let selectMenu = this.client.selectmenus.get(idWithoutUser);

        if (!selectMenu) {
            const checkCustomId = this.client.selectmenus.get(interaction.customId.replace(/[0-9]/g, ""));
            if (!checkCustomId) {
                await interaction.reply({
                    content: `${language.error}`,
                    ephemeral: false
                });
                return;
            }
            
            const user = await getMemberFromID(interaction, interaction.customId.replace(/[a-zA-Z]/g, "").replace(/-/g, ""));
            if (user) {
                await interaction.reply({
                    content: `${language.not_allowed_select_menu
                        .replace(/{user.id}/g, `${user.id}`)
                    }`,
                    ephemeral: true
                });
                return;
            } else {
                await interaction.reply({
                    content: `${language.error}`,
                    ephemeral: false
                });
                return;
            }
        }

        try {
            await selectMenu.run(interaction, _language);
        } catch (error) {
            this.client.emit("selectMenuError", error, interaction, _language);
        }
    }

    private async handleSlashCommand(
        interaction: ChatInputCommandInteraction,
        language: typeof languages[supportLanguages],
        _language: supportLanguages
    ) {
        const slashCommand = this.client.slashcommands.get(interaction.commandName);
        if (!slashCommand) {
            await interaction.reply({
                content: `${language.error}`,
                ephemeral: false
            });
            return;
        }

        if (!slashCommand.data.dm_permission && !interaction.guild) {
            await interaction.reply({
                content: `${language.slash_only_servers
                    .replace(/{fail}/g, `${this.client.emoji.fail}`)
                }`,
                ephemeral: true,
            });
            return;
        }

        const args: any[] = [];
        for (const option of interaction.options.data) {
            if (option.type === ApplicationCommandOptionType.Subcommand) {
                if (option.name) args.push(option.name);
                option.options?.forEach(x => {
                    if (x.value !== undefined) args.push(x.value);
                });
            } else if (option.value !== undefined) {
                args.push(option.value);
            }
        }
        
        try {
            await slashCommand.run(interaction, args, _language);
        } catch (error) {
            this.client.emit("slashCommandError", error, interaction, _language);
        }
    }
}

async function getMemberFromID(interaction: Interaction, id: string): Promise<GuildMember | null> {
    if (!interaction.guild) return null;
    try {
        const members = await interaction.guild.members.fetch();
        return members.get(id) ?? null;
    } catch {
        return null;
    }
}
