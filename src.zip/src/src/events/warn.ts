import Event from "../structures/Event";
import logger from "../utils/logger";

export default class extends Event {
    public async run(message: any) {
        logger.warn(message, {
            label: "Warn event"
        });
    }
};
