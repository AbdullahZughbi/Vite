import Event from "../../structures/Event";
import config from "../../../config";
import logger from "../../utils/logger";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/events/errors/commandError";
import {
    WebhookClient,
    Guild,
    GuildMember,
    EmbedBuilder,
    Message,
    TextChannel,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
} from "discord.js";

const webhookClient = new WebhookClient({
    url: config.webhooks.errors!,
});

export default class extends Event {
    public async run(
        error: any,
        message: Message,
        cmd: string,
        args: string[],
        _language: supportLanguages
    ): Promise<void> {
        const language = languages[_language];

        if (error.code === "ECONNREFUSED") {
            (message.channel as TextChannel).send({
                content: `${language.unable_connect_database.replace(
                    /{warning}/g,
                    `${this.client.emoji.yellow_warning}`
                )}`,
                components: [
                    new ActionRowBuilder<ButtonBuilder>().addComponents(
                        new ButtonBuilder()
                            .setLabel(`${language.report}`)
                            .setStyle(ButtonStyle.Link)
                            .setURL(`${config.discord}`)
                    ),
                ],
            }).catch(() => {});
            return;
        }

        (message.channel as TextChannel).send(
            `${language.error
                .replace(/{fail}/g, `${this.client.emoji.fail}`)
                .replace(/{discord}/, `${config.discord}`)}`
        ).catch(() => {});

        let content = message.content;
        if (content.length > 1024) content = content.slice(0, 1021) + "...";

        console.error(error);

        const embed = new EmbedBuilder()
            .setTitle("Command Error")
            .setThumbnail((message.member as GuildMember).displayAvatarURL())
            .addFields([
                {
                    name: "Guild",
                    value: `**${(message.guild as Guild).name}** (${(message.guild as Guild).id})`,
                    inline: true,
                },
                {
                    name: "User",
                    value: `<@${(message.member as GuildMember).id}> **${(message.member as GuildMember).user.username}** (${(message.member as GuildMember).id})`,
                    inline: true,
                },
                {
                    name: "Command Name",
                    value: `${cmd}`,
                    inline: true,
                },
                {
                    name: "Content",
                    value: `${content}`,
                    inline: true,
                },
                {
                    name: "Error",
                    value: `${error.message}`,
                    inline: true,
                }
            ])
            .setColor("#050000");

        webhookClient.send({
            embeds: [embed],
        });
    }
};
