import Event from "../../structures/Event";
import config from "../../../config";
import logger from "../../utils/logger";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/events/errors/apiError";
import {
    EmbedBuilder,
    Guild,
    GuildMember,
    WebhookClient,
    Message,
    TextChannel
} from "discord.js";

const webhookClient = new WebhookClient({
    url: config.webhooks.errors!,
});

export default class extends Event {
    public async run(
        error: any,
        message: Message,
        _language: supportLanguages
    ): Promise<void> {
        const language = languages[_language];
        
        (message.channel as TextChannel).send(`${language.error
            .replace(/{discord}/g, `${config.discord}`)
        }`).catch(() => {});
        
        let content = message.content;
        if (content.length > 1024) content = content.slice(0, 1021) + "...";
        
        console.error(error);
        
        const embed = new EmbedBuilder()
            .setTitle("API Error")
            .setThumbnail((message.member as GuildMember).displayAvatarURL() as string)
            .addFields([
                {
                    name: "Guild",
                    value: `**${(message.guild as Guild).name}** (${(message.guild as Guild).id})`,
                    inline: true,
                },
                {
                    name: "User",
                    value: `<@${(message.member as GuildMember).id}> **${(message.member as GuildMember).user.username}** (${(message.member as GuildMember).id})`,
                    inline: true,
                },
                {
                    name: "Content",
                    value: `${content}`,
                    inline: true,
                },
                {
                    name: "Error",
                    value: `${error.message}`,
                    inline: true,
                }
            ])
            .setColor("#050000");
        
        webhookClient.send({
            embeds: [embed],
        });
    }
};
