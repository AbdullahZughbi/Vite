import Event from "../../structures/Event";
import config from "../../../config";
import logger from "../../utils/logger";
import type { supportLanguages } from "../../database/schemas/Guild";
import languages from "../../data/languages/events/errors/buttonError";
import {
    ButtonInteraction,
    GuildMember,
    Guild,
    WebhookClient,
    EmbedBuilder
} from "discord.js";

const webhookClient = new WebhookClient({
    url: config.webhooks.errors!,
});

export default class extends Event {
    public async run(
        error: any,
        interaction: ButtonInteraction,
        _language: supportLanguages
    ): Promise<void> {
        const language = languages[_language];
        
        await interaction.followUp({
            content: `${language.error
                .replace(/{fail}/g, `${this.client.emoji.fail}`)
                .replace(/{discord}/g, `${config.discord}`)
            }`,
            ephemeral: false,
        }).catch(() => console.error);
        
        console.error(error);
        
        const embed = new EmbedBuilder()
            .setTitle("Button Error")
            .setThumbnail((interaction.member as GuildMember).displayAvatarURL())
            .setColor("#050000");
        
        if ((interaction.guild as Guild)) {
            embed.addFields({
                name: "Guild",
                value: `**${(interaction.guild as Guild).name}** (${(interaction.guild as Guild).id})**`,
                inline: true,
            });
        }
        
        embed
            .addFields([
                {
                    name: "User",
                    value: `<@${interaction.user.id}> **${interaction.user.username}** (${interaction.user.id})`,
                    inline: true,
                },
                {
                    name: "Custom ID",
                    value: `${interaction.customId}`,
                    inline: true,
                },
                {
                    name: "Error",
                    value: `${error.message}`,
                    inline: true,
                }
            ]);
        
        webhookClient.send({
            embeds: [embed],
        });
    }
};
