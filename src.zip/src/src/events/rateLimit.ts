import Event from "../structures/Event";
import logger from "../utils/logger";
import { EmbedBuilder, WebhookClient } from "discord.js";
import config from "../../config";

const webhookClient = new WebhookClient({
    url: config.webhooks.ratelimit_logs!
});

export default class extends Event {
    public async run(rl: {
        timeout: number;
        limit: number;
        method: string;
        path: string;
        route?: string;
    }): Promise<void> {
        const embed = new EmbedBuilder()
            .setColor("#050000")
            .setDescription(
                `**Time out**\n\`${rl.timeout}ms\`\n**Limit:**\n\`${rl.limit}\`\n\n__**Information**__\n**Method:** ${rl.method}\n\n**Path:**\n${rl.path} ${rl.route || ""}`
            )
            .setTimestamp();

        setTimeout(() => {
            webhookClient.send({ embeds: [embed] });
            logger.info(`Time out: ${rl.timeout}ms. Limit: ${rl.limit}`, {
                label: "Rate Limit",
            });
        }, rl.timeout + 10);
    }
};
