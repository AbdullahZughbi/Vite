import Event from "../../structures/Event";

export default class extends Event {
    async run(closeEvent: any, shardId: any) {
      
    }
};
