import Event from "../../structures/Event";

export default class extends Event {
    async run(error: any, shardId: any) {
      
    }
};
