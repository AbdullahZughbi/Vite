import Event from "../structures/Event";
import { WebhookClient, EmbedBuilder } from "discord.js";
import config from "../../config";
import logger from "../utils/logger";
import Maintenance from "../database/schemas/maintenance";

const webhookClient = new WebhookClient({ url: config.webhooks.maintenance_logs! });
let number = 1;

export default class MaintenanceEvent extends Event {
    public async run(info: string): Promise<void> {
        if (!info.includes("hit")) return;

        if (config.maintenance === "true") {
            // Get Maintenance model by passing sequelize instance from client
            const MaintenanceModel = Maintenance(this.client.sequelize);

            const maintenance = await MaintenanceModel.findOne({ where: { maintenance: "maintenance" } });
            if (!maintenance) {
                logger.error("Maintenance document not found", { label: "MaintenanceEvent" });
                return;
            }

            number++;

            let embedText = `${info} - ${number}`;
            logger.info(info, { label: "Debug" });

            if (number >= parseInt(config.maintenance_threshold)) {
                embedText = `${info} - ${number} - SAFE MODE REACHED`;

                const maintenanceEmbed = new EmbedBuilder()
                    .setDescription(embedText)
                    .setColor("#050000");

                await webhookClient.send({
                    embeds: [maintenanceEmbed],
                });

                console.log("Safe mode reached - Turning maintenance mode on.");
                maintenance.toggle = "true";
                await maintenance.save();
            }
        }
    }
};
