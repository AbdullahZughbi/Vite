import {
    WebhookClient,
    EmbedBuilder,
    User,
    Guild as DiscordGuild
} from "discord.js";
import config from "../../config";
import GuildDB, { Guild as GuildModel } from "../database/schemas/Guild";
import parseJsonDeep from "../utils/parseJsonDeep";
import { ModelStatic } from "sequelize";
import Event from "../structures/Event";
import logger from "../utils/logger";
import ExtendedClient from "../structures/ExtendedClient";

const premiumrip = new WebhookClient({ url: config.webhooks.premium! });

export default class ReadyEvent extends Event {
    public async run() {
        logger.info(
            `${this.client.user!.tag} is ready to servers ${this.client.guilds.cache.size} guilds.`,
            { label: "Ready" }
        );

        const Guild = GuildDB(this.client.sequelize);

        setInterval(async () => {
            const conditional = { isPremium: true };
            const results = await Guild.findAll({ where: conditional });

            if (results.length === 0) return;

            for (const result of results) {
                if (!result.premium) continue;

                const rawPremium = parseJsonDeep(result.premium);
                if (!rawPremium) continue;

                const premium = {
                    ...rawPremium,
                    redeemedAt: rawPremium.redeemedAt ? new Date(rawPremium.redeemedAt) : null,
                    expiresAt: rawPremium.expiresAt ? new Date(rawPremium.expiresAt) : null,
                };

                result.premium = premium;

                if (!premium.expiresAt) continue;
                const expiresAtDate = premium.expiresAt;

                if (expiresAtDate.getTime() <= Date.now()) {
                    const guildPremium = this.client.guilds.cache.get(result.guildId);
                    if (!guildPremium) continue;

                    const userId = premium.redeemedBy?.id;
                    if (!userId) continue;

                    const user = await this.client.users.fetch(userId).catch(() => null);
                    if (user) {
                        const embed = new EmbedBuilder()
                            .setColor("#050000")
                            .setDescription(`Hey <@${user.id}>, premium in **${guildPremium.name}** was expired`);

                        user.send({ embeds: [embed] }).catch(() => {});
                    }

                    const rip = new EmbedBuilder()
                        .setTitle("Premium Subscription")
                        .setDescription("Guild premium was expired")
                        .addFields([
                            {
                                name: "Premium Code",
                                value: premium.code || "N/A",
                                inline: true
                            },
                            {
                                name: "Redeem Date",
                                value: premium.redeemedAt ? `<t:${Math.floor(premium.redeemedAt.getTime() / 1000)}:f>` : "N/A",
                                inline: true,
                            },
                            {
                                name: "Expires At",
                                value: `<t:${Math.floor(expiresAtDate.getTime() / 1000)}:f>`,
                                inline: true,
                            },
                            {
                                name: "Guild",
                                value: `**${guildPremium.name}** (${guildPremium.id})`,
                                inline: true
                            },
                            {
                                name: "User",
                                value: `<@${premium.redeemedBy?.id}> **${premium.redeemedBy?.username || "Unknown"}** (${premium.redeemedBy?.id})`,
                                inline: true,
                            },
                        ])
                        .setColor("#050000")
                        .setTimestamp();

                    await premiumrip.send({
                        username: "GOD Premium",
                        avatarURL: `${process.env.AUTH_DOMAIN}/logo.png`,
                        embeds: [rip],
                    }).catch(() => {});

                    // Reset premium data forcibly
                    result.isPremium = false;
                    (result.premium as any).redeemedBy.id = null as any;
                    (result.premium as any).redeemedBy.username = null;
                    (result.premium as any).redeemedAt = null;
                    (result.premium as any).expiresAt = null as any;
                    (result.premium as any).code = null;

                    await result.save();
                }
            }
        }, 60_000);

        // Silences TS error for incompatible description types
        this.client.application!.commands.set(
            this.client.slashcommands.map((x) => x.data as any)
        );

        if (config.dashboard === "true") {
            const Dashboard = (await import("../dashboard/dashboard")).default;
            await Dashboard(this.client);
        }
    }
}
