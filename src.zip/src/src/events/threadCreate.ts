import Event from "../structures/Event";

export default class extends Event {
    public async run(thread: any): Promise<void> {
        try {
            await thread.join();
        } catch (err) {
            // silently ignore errors
        }
    }
};
