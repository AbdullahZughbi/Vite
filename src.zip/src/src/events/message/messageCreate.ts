import Event from "../../structures/Event";
import {
    PermissionsBitField,
    Collection,
    GuildMember,
    Message,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    TextChannel,
    Guild as _Guild,
    ButtonStyle,
    GuildChannel
} from "discord.js";
import logger from "../../utils/logger";
import GuildDB, { supportLanguages } from "../../database/schemas/Guild";
import BlacklistDB from "../../database/schemas/blacklist";
import permissions from "../../assets/json/permissions";
import MaintenanceDB from "../../database/schemas/maintenance";
import config from "../../../config";
import languages from "../../data/languages/events/message/messageCreate";
import parseJsonDeep from "../../utils/parseJsonDeep";

const maintenanceCooldown = new Set();

interface UserRateLimits {
    [commandName: string]: number;
}

export default class extends Event {
    private ratelimits: Collection<string, UserRateLimits>;

    constructor(...args: [any, any]) {
        super(...args);

        this.ratelimits = new Collection();
    }

    public async run(message: Message): Promise<any> {
        let __language: supportLanguages = "English";
        try {
            if (!message.guild || message.author.bot) return;

            const mentionRegex = RegExp(`^<@!?${(this.client.user as any).id}>$`);
            const mentionRegexPrefix = RegExp(`^<@!?${(this.client.user as any).id}>`);

            const _GuildDB = GuildDB(this.client.sequelize);

            let settings = await _GuildDB.findOne({
                where: {
                    guildId: (message.guild as _Guild).id,
                },
            });

            if (!settings) {
                settings = await _GuildDB.create({
                    guildId: (message.guild as _Guild).id,
                });
            }
            
            const language = languages[settings.language as supportLanguages];
            __language = settings.language;
            const Maintenance = MaintenanceDB(this.client.sequelize);
            const Blacklist = BlacklistDB(this.client.sequelize);

            if (message.content.match(mentionRegex)) {
                if (!language) return await this.couldntFindLanguage(message, __language);
                
                const prefix = settings.prefix;

                const button = new ButtonBuilder()
                    .setLabel(`${language.invite}`)
                    .setStyle(ButtonStyle.Link)
                    .setURL(config.invite_link!);
                const button3 = new ButtonBuilder()
                    .setLabel(`${language.support}`)
                    .setStyle(ButtonStyle.Link)
                    .setURL(config.discord!);
                const row = new ActionRowBuilder<ButtonBuilder>().addComponents(button, button3);
                const embed = new EmbedBuilder()
                    .setDescription(`${language.hi
                        .replace(/{prefix}/g, prefix)
                    }`)
                    .setFooter({
                        text: `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})`,
                        iconURL: (message.member as GuildMember).displayAvatarURL(),
                    })
                    .setColor("#050000");

                (message.channel as TextChannel).send({ embeds: [embed], components: [row] });
            }

            let mainPrefix = settings ? settings.prefix : "G!";
            const prefix = message.content.startsWith(settings.prefix)
                ? settings.prefix
                : message.content.match(mentionRegexPrefix)?.[0] || mainPrefix;

            const userBlacklistSettings = await Blacklist.findOne({
                where: {
                    discordId: (message.member as GuildMember).id,
                },
            });

            const guildBlacklistSettings = await Blacklist.findOne({
                where: {
                    guildId: (message.guild as _Guild).id,
                },
            });

            if (!message.content.startsWith(prefix)) return;
            const [cmd, ...args] = message.content.slice(prefix.length).trim().split(/ +/g);
            const command = this.client.commands.get(cmd.toLowerCase());

            if (command) {
                if (!language) return await this.couldntFindLanguage(message, __language);
                
                let disabledCommands = parseJsonDeep(settings.disabledCommands) || [];

                const commandName = typeof command === "string" ? command : command.name;
                if ((disabledCommands as unknown as string[]).includes(commandName)) return;
                
                const rateLimit = this.ratelimit(message, cmd, __language);

                if (userBlacklistSettings && userBlacklistSettings.isBlacklist) {
                    logger.warn(
                        `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id}) tried to use "${cmd}" command but the user is blacklisted. Guild: **${(message.guild as _Guild).name}** (${(message.guild as _Guild).id})`,
                        { label: "Commands" }
                    );
                    
                    const durationText = userBlacklistSettings.length
                        ? ` ${language.userBlacklist.for} <t:${Math.floor((userBlacklistSettings.length as unknown as Date).getTime() / 1000)}:F>`
                        : "";
                    
                    const reasonText = userBlacklistSettings.reason
                        ? `\`\`\`${language.userBlacklist.reason}: ${userBlacklistSettings.reason}\`\`\``
                        : language.userBlacklist.noReason;
                    
                    const _message = language.userBlacklist.message
                        .replace("{duration}", durationText)
                        .replace("{reason}", reasonText);

                    (message.channel as TextChannel).send(
                        `${_message}`
                    ).catch(() => {});

                    const guildOwner = await (message.guild as _Guild).fetchOwner().then((m: any) => m.user).catch(() => {});
                    if ((message.member as GuildMember).id === guildOwner.id) {
                        if (!guildBlacklistSettings) {
                            await Blacklist.create({
                                guildId: (message.guild as _Guild).id,
                                type: "guild",
                                isBlacklist: true,
                                length: userBlacklistSettings.length ? (userBlacklistSettings.length as unknown as Date) : null,
                                reason: userBlacklistSettings.reason || null,
                            });
                        }
                        await (message.guild as _Guild).leave().catch(() => {});
                    }
                    return;
                }

                if (guildBlacklistSettings && guildBlacklistSettings.isBlacklist) {
                    logger.warn(
                        `<@${(message.member as GuildMember).id}> **${(message.member as GuildMember).user.username}** (${(message.member as GuildMember).id}) tried to use "${cmd}" command but the guild: ${(message.guild as _Guild).name} ${(message.guild as _Guild).id} is blacklisted`,
                        { label: "Commands" }
                    );
                    
                    const durationText = guildBlacklistSettings.length
                        ? `${language.guildBlacklist.for} <t:${Math.floor((guildBlacklistSettings.length as Date).getTime() / 1000)}:F>`
                        : "";
                        
                    const reasonText = guildBlacklistSettings.reason
                        ? `\`\`\`${language.guildBlacklist.reason}: ${guildBlacklistSettings.reason}\`\`\``
                        : language.guildBlacklist.noReason;
                    
                    const _message = language.guildBlacklist.message
                        .replace("{duration}", durationText)
                        .replace("{reason}", reasonText);
                    
                    (message.channel as TextChannel).send(
                        `${_message}`
                    ).catch(() => {});
                    await (message.guild as _Guild).leave().catch(() => {});
                    return;
                }

                const number = Math.floor(Math.random() * 10 + 1);
                if (typeof rateLimit === "number") {
                    return (message.channel as TextChannel)
                        .send(
                            `${message.member} ${this.client.emoji.fail} ${language.ratelimit
                                .replace(/{rateLimit}/g, `${rateLimit}`)
                                .replace(/{cmd}/g, cmd)
                            }`
                        )
                        .then((s: any) => {
                            message.delete().catch(() => {});
                            setTimeout(() => {
                                s.delete().catch(() => {});
                            }, 4000);
                        })
                        .catch(() => {});
                }

                if (command.botPermission) {
                    let missingPermissions: string[] = [];
                    const botMember = (message.guild as _Guild).members.me as GuildMember;
                    const channel = message.channel as TextChannel | null;

                    if (channel && botMember) {
                        missingPermissions = channel
                            .permissionsFor(botMember.id)
                            ?.missing(command.botPermission)
                            .map((p: keyof typeof permissions | string) => permissions[p as keyof typeof permissions]) || [];
                    }

                    if (missingPermissions.length !== 0) {
                        const embedd = new EmbedBuilder()
                            .setDescription(`${language.botPermission
                                .replace(/{fail}/g, `${this.client.emoji.fail}`)
                                .replace(/{missingPermissions}/g, `${
                                    missingPermissions.join(", ")
                                }`)
                                .replace(/{link}/g, `https://${process.env.DOMAIN}/help/other-permissions`)
                            }`)
                            .setColor("#992d22");
                        return (message.channel as TextChannel).send({ embeds: [embedd] }).catch(() => {});
                    }
                }

                if (command.userPermission) {
                    let missingPermissions: string[] = [];
                    const channel = message.channel as TextChannel | GuildChannel | null;
                    const member = message.member as GuildMember | null;

                    if (channel && member) {
                        missingPermissions = channel
                            .permissionsFor(member.id)
                            ?.missing(command.userPermission)
                            .map((p: keyof typeof permissions | string) => permissions[p as keyof typeof permissions]) || [];
                    }

                    if (missingPermissions.length !== 0) {
                        const embed = new EmbedBuilder()
                            .setAuthor({
                                name: `${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})`,
                                iconURL: (message.member as GuildMember).displayAvatarURL(),
                            })
                            .setDescription(`${language.userPermission
                                .replace(/{missingPermissions}/g, `${missingPermissions.join(", ")}`)
                            }`)
                            .setColor(`#000000`);
                        return (message.channel as TextChannel).send({ embeds: [embed] }).catch(() => {});
                    }
                }

                if (command.ownerOnly) {
                    if (!this.client.config.developers.includes((message.member as GuildMember).id)) return;
                }

                if (command.disabled) {
                    const disabledButton = new ButtonBuilder()
                        .setCustomId(`${language.disabledCommand.support}`)
                        .setStyle(ButtonStyle.Link)
                        .setURL(config.discord!);
                    const disabledRow = new ActionRowBuilder<ButtonBuilder>().addComponents(disabledButton);
                    return (message.channel as TextChannel).send({
                        content: `${language.disabledCommand.message}`,
                        components: [disabledRow],
                    });
                }

                await this.runCommand(message, cmd, args, settings.language);
            }
        } catch (error) {
            return this.client.emit("fatalError", error, message, __language);
        }
    }

    private async runCommand(message: Message, cmd: string, args: string[], language: supportLanguages): Promise<void> {
        const command = this.client.commands.get(cmd.toLowerCase());

        if (command) {
            const baseLog = `(${command.name}) ran by "${(message.member as GuildMember).user.username} (${(message.member as GuildMember).id})" on guild "${(message.guild as _Guild).name}" (${(message.guild as _Guild).id}) channel "#${(message.channel as GuildChannel).name}" (${(message.channel as GuildChannel).id})`;
            const maxLength = 2000;
            const allowedContentLength = Math.max(0, maxLength - baseLog.length - 200);
            const content = message.content.length > allowedContentLength
                ? message.content.slice(0, allowedContentLength - 3) + "..."
                : message.content;
            const logMessage = `"${content}" ${baseLog}`;
            logger.info(logMessage, { label: "Command" });
            
            try {
                await command.run(message, args, language);
            } catch (error) {
                this.client.emit("commandError", error, message, cmd, args, language);
            }
        }
    }

    private ratelimit(message: Message, cmd: string, language: supportLanguages): boolean | number | null {
        try {
            const command = this.client.commands.get(cmd.toLowerCase());
            if (!command) return false;

            const cooldown = command.cooldown * 1000;
            const userRateLimits = this.ratelimits.get((message.member as GuildMember).id) || {};

            if (!userRateLimits[command.name]) {
                userRateLimits[command.name] = Date.now() - cooldown;
            }

            const lastUsed = userRateLimits[command.name];
            const difference = Date.now() - lastUsed;

            if (difference < cooldown) {
                const cooldownEnd = Math.floor((lastUsed + cooldown) / 1000);
                return cooldownEnd;
            } else {
                userRateLimits[command.name] = Date.now();
                this.ratelimits.set((message.member as GuildMember).id, userRateLimits);
                return true;
            }
        } catch (e) {
            this.client.emit("fatalError", e, message, language);
            return false;
        }
    }
    
    private async couldntFindLanguage(
        message: Message,
        language: string
    ): Promise<void> {
        const embed = new EmbedBuilder()
            .setDescription(`Sorry, I couldn't find language data for **${language}**.`)
            .setColor("#992d22");
        
        const supportButton = new ButtonBuilder()
            .setLabel("Report it here")
            .setStyle(ButtonStyle.Link)
            .setURL(config.discord!);
        
        const row = new ActionRowBuilder<ButtonBuilder>().addComponents(supportButton);
        
        await (message.channel as TextChannel).send({
            embeds: [embed],
            components: [row]
        }).catch(() => {});
        return;
    }
};
