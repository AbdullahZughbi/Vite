import {
    ChatInputCommandInteraction,
    ApplicationCommandOptionData,
    PermissionsString
} from "discord.js";
import ExtendedClient from "./ExtendedClient";
import type {
    supportLanguages
} from "../database/schemas/Guild";

interface DataOptions {
    name?: string;
    description?: string;
    options?: ApplicationCommandOptionData[];
    dm_permission?: boolean;
    integration_types?: string[];
    contexts?: string;
}

interface OtherOptions {
    category: string;
    usage?: string;
    examples?: string[];
    disabled?: boolean;
    cooldown?: number;
    userPermission?: PermissionsString[];
    botPermission?: PermissionsString[];
}

interface SlashCommandOptions {
    data?: DataOptions;
    other?: OtherOptions;
}

export default class Command {
    public client: ExtendedClient;
    public name: string;
    public data: DataOptions;
    public other: OtherOptions;
    
    constructor(
        client: ExtendedClient,
        name: string,
        options: SlashCommandOptions = {}
    ) {
        this.client = client;
        this.name = options.data?.name || name;
        this.data = {
            name: options.data?.name || name,
            description: options.data?.description || "No description provided.",
            options: options.data?.options || [],
            dm_permission: options.data?.dm_permission ?? false,
            integration_types: options.data?.integration_types,
            contexts: options.data?.contexts
        };
        this.other = {
            category: options.other?.category || "uncategorized",
            usage: options.other?.usage || "No usage provided.",
            examples: options.other?.examples || [],
            disabled: options.other?.disabled || false,
            cooldown: typeof options.other?.cooldown === "number" ? options.other.cooldown : 5,
            userPermission: options.other?.userPermission || [],
            botPermission: options.other?.botPermission || []
        };
    }

    public async run(
        interaction: ChatInputCommandInteraction,
        args: string[],
        _language: supportLanguages
    ): Promise<void> {
        throw new Error(`The run method has not been implemented in ${this.name}`);
    }
};
