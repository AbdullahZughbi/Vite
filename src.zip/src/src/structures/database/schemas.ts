export default [
    "blacklist",
    "GOD",
    "Guild",
    "maintenance"
] as string[];
