import fs from "fs/promises";
import path from "path";
import { Stats } from "fs";
import { pathToFileURL, fileURLToPath } from "url";
import { Client, Collection } from "discord.js";
import Command from "./Command";
import Modal from "./Modal";
import Event from "./Event";
import Button from "./Button";
import SelectMenu from "./SelectMenu";
import SlashCommand from "./SlashCommand";
import ContextMenuCommand from "./ContextMenuCommand";
import logger from "../utils/logger";
import { Sequelize } from "sequelize";
import ExtendedClient from "./ExtendedClient";
import models from "./database/models";
import schemas from "./database/schemas";

export default class Util {
    public client: ExtendedClient;

    constructor(client: ExtendedClient) {
        this.client = client;
    }

    private isClass(input: unknown): boolean {
        return (
            typeof input === "function" &&
            typeof (input as any).prototype === "object" &&
            input.toString().startsWith("class")
        );
    }

    private trimArray(arr: string[], maxLen: number = 10): string[] {
        if (arr.length > maxLen) {
            const len: number = arr.length - maxLen;
            arr = arr.slice(0, maxLen);
            arr.push(`${len} more...`);
        }
        return arr;
    }

    private get directory(): string {
        const mainFilename: string =
            typeof require !== "undefined" &&
            typeof require.main !== "undefined" &&
            typeof require.main.filename === "string"
                ? require.main.filename
                : process.cwd();

        return path.dirname(mainFilename) + path.sep;
    }

    private removeDuplicates<T>(arr: T[]): T[] {
        return [...new Set(arr)];
    }

    private capitalise(str: string): string {
        return str
            .split(" ")
            .map((s: string): string => s.charAt(0).toUpperCase() + s.slice(1))
            .join(" ");
    }

    private async *loadFiles(dir: string): AsyncGenerator<string, void, unknown> {
        try {
            await fs.access(dir);
        } catch {
            await fs.mkdir(dir, { recursive: true });
        }

        const files: string[] = await fs.readdir(dir);
        for (const file of files) {
            const filePath: string = path.join(dir, file);
            const stat: Stats = await fs.stat(filePath);
            if (stat.isDirectory()) {
                yield* this.loadFiles(filePath);
            } else {
                if (!file.endsWith(".ts") && !file.endsWith(".js")) continue;
                yield filePath;
            }
        }
    }

    public async loadDatabases(): Promise<void> {
        try {
            await this.client.sequelize.authenticate();
            logger.info("Connection", { label: "DATABASE" });
        } catch (err) {
            throw err;
        }

        for (const schema of schemas as string[]) {
            const { default: applySchema }: { default: (sequelize: Sequelize) => void } = await import(`../database/schemas/${schema}`);
            applySchema(this.client.sequelize);
        }

        for (const model of models as string[]) {
            const { default: applyModel }: { default: (sequelize: Sequelize) => void } = await import(`../database/models/${model}`);
            applyModel(this.client.sequelize);
        }

        await this.client.sequelize.sync({ force: false });
        logger.info("Resync", { label: "DATABASE" });
    }

    private async loadClassFromFile<T>(
        file: string,
        BaseClass: new (...args: any[]) => T,
        name: string,
        instanceArgs: any[] = []
    ): Promise<T> {
        const imported: any = await import(file);
        const Class: new (...args: any[]) => T = imported.default ?? imported;
        if (!this.isClass(Class)) throw new TypeError(`${name} doesn't export a class.`);
        const instance: T = new Class(...instanceArgs);
        if (!(instance instanceof BaseClass)) throw new TypeError(`${name} doesn't belong in ${BaseClass.name}s.`);
        return instance;
    }

    public async loadCommands(): Promise<void> {
        for await (const file of this.loadFiles(`${this.directory}/src/commands`) as AsyncGenerator<string>) {
            const { name }: { name: string } = path.parse(file);
            const command: Command = await this.loadClassFromFile<Command>(file, Command, `Command ${name}`, [this.client, name.toLowerCase()]);
            this.client.commands.set(command.name, command);
            for (const alias of (command.aliases ?? []) as string[]) {
                this.client.aliases.set(alias, command.name);
            }
        }
    }

    public async loadSlashCommands(): Promise<void> {
        for await (const file of this.loadFiles(`${this.directory}/src/slashCommands`)) {
            const { name }: { name: string } = path.parse(file);
            const slash: SlashCommand = await this.loadClassFromFile<SlashCommand>(file, SlashCommand, `Slash command ${name}`, [this.client, name.toLowerCase()]);
            this.client.slashcommands.set(slash.name, slash);
        }
    }

    public async loadButtons(): Promise<void> {
        for await (const file of this.loadFiles(`${this.directory}/src/components/buttons`)) {
            const { name }: { name: string } = path.parse(file);
            const button: Button = await this.loadClassFromFile<Button>(file, Button, `Button ${name}`, [this.client, name]);
            this.client.buttons.set(button.name, button);
        }
    }

    public async loadContextMenuCommands(): Promise<void> {
        for await (const file of this.loadFiles(`${this.directory}/src/contextMenuCommands`)) {
            const { name }: { name: string } = path.parse(file);
            const cmd: ContextMenuCommand = await this.loadClassFromFile<ContextMenuCommand>(file, ContextMenuCommand, `Context Menu Command ${name}`, [this.client, name]);
            this.client.contextmenucommands.set(cmd.name, cmd);
        }
    }

    public async loadSelectMenus(): Promise<void> {
        for await (const file of this.loadFiles(`${this.directory}/src/components/selectMenus`)) {
            const { name }: { name: string } = path.parse(file);
            const select: SelectMenu = await this.loadClassFromFile<SelectMenu>(file, SelectMenu, `Select Menu ${name}`, [this.client, name]);
            this.client.selectmenus.set(select.name, select);
        }
    }

    public async loadModals(): Promise<void> {
        for await (const file of this.loadFiles(`${this.directory}/src/components/modals`)) {
            const { name }: { name: string } = path.parse(file);
            const modal: Modal = await this.loadClassFromFile<Modal>(file, Modal, `Modal ${name}`, [this.client, name]);
            this.client.modals.set(modal.name, modal);
        }
    }

    public async loadEvents(): Promise<void> {
        for await (const file of this.loadFiles(`${this.directory}/src/events`)) {
            const { name }: { name: string } = path.parse(file);
            const event: Event = await this.loadClassFromFile<Event>(file, Event, `Event ${name}`, [this.client, name]);
            this.client.events.set(event.name, event);
            event.emitter[event.type](name, (...args: any[]): void => {
                void event.run(...args);
            });
        }
    }
};
