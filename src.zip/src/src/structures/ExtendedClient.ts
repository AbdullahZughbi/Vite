import {
    Client,
    Collection,
} from "discord.js";
import {
    Sequelize,
} from "sequelize";
import Util from "./Util";
import config from "../../config";
import emoji from "../data/emoji";
import Command from "./Command";
import SlashCommand from "./SlashCommand";
import ContextMenuCommand from "./ContextMenuCommand";
import Button from "./Button";
import SelectMenu from "./SelectMenu";
import Modal from "./Modal";
import Event from "./Event";

export default class ExtendedClient extends Client {
    public sequelize!: Sequelize;
    public commands!: Collection<string, Command>;
    public aliases!: Collection<string, string>;
    public slashcommands!: Collection<string, SlashCommand>;
    public contextmenucommands!: Collection<string, ContextMenuCommand>;
    public buttons!: Collection<string, Button>;
    public selectmenus!: Collection<string, SelectMenu>;
    public modals!: Collection<string, Modal>;
    public events!: Collection<string, Event>;
    public emoji!: typeof emoji;
    public utils!: Util;
    public config!: typeof config;
    public prefix!: string;
    public ratelimits = {
        dashboard: {
            settings: new Map<string, number>(),
        },
    };

    constructor(public options: any) {
        super(options);
    }
};
