import ExtendedClient from "./ExtendedClient";

interface EventOptions {
  once?: boolean;
  emitter?: string | NodeJS.EventEmitter;
}

export default class Event {
    public client: ExtendedClient;
    public name: string;
    public type: "on" | "once";
    public emitter: NodeJS.EventEmitter;
    
    constructor(
        client: ExtendedClient,
        name: string,
        options: EventOptions = {}
    ) {
        this.client = client;
        this.name = name;
        this.type = options.once ? "once" : "on";
        this.emitter =
            typeof options.emitter === "string"
                ? (this.client as any)[options.emitter]
                : options.emitter || this.client;
    }
    
    public async run(...args: any[]): Promise<void> {
        throw new Error(`The run method has not been implemented in ${this.name}`);
    }
};
