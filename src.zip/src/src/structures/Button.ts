import {
    Interaction
} from "discord.js";
import ExtendedClient from "./ExtendedClient";
import type {
    supportLanguages
} from "../database/schemas/Guild";

interface ButtonOptions {
    name?: string;
}

export default class Button {
    public client: ExtendedClient;
    public name: string;
    
    constructor(
        client: ExtendedClient,
        name: string,
        options: ButtonOptions
    ) {
        this.client = client;
        this.name = options.name || name;
    }
    
    public async run(
        interaction: Interaction,
        _language: supportLanguages
    ): Promise<void> {
        throw new Error(`The run method has not been implemented in ${this.name}`);
    }
};
