const English = {
    not_allowed: "You are not allowed to do that! Only <@{member.id}> can use these buttons.",
    interaction_ended: "Interaction ended."
};

export default English;
