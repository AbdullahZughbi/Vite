import English from "./ButtonMenu/English";

export default {
    English,
    
} as const;
