const English = {
    invalid_role: "Invalid Role",
    please_valid_role: "Please provide a valid role mention / role name / role ID",
    footer_text: "Usage: {usage}\nExamples: {examples}",
    information: "{role.name} Information",
    fields: {
        role: "Role",
        role_id: "Role ID",
        color: "Color",
        hoisted: "Hoisted",
        mentionable: "Mentionable",
        position: "position",
        managed: "Managed",
        created_at: "Created at",
        permissions: "Permissions"
    }
};

export default English;
