const English = {
    title: "{user} Permissions"
};

export default English;
