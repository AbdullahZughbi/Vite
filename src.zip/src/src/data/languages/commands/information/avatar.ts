import English from "./avatar/English";

export default {
    English,
    
} as const;
