import English from "./serverinfo/English";

export default {
    English,
    
} as const;
