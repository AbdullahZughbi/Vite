import English from "./userinfo/English";

export default {
    English,
    
} as const;
