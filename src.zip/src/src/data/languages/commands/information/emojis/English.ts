const English = {
    not_found: "No emojis found!",
    emoji_list: "Emoji List"
};

export default English;
