import English from "./uptime/English";

export default {
    English,
    
} as const;
