const English = {
    not_found: "No humans found!",
    list_of_humans: "List of humans",
    requested_by: "Requested by"
};

export default English;
