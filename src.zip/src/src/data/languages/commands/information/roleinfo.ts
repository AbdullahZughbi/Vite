import English from "./roleinfo/English";

export default {
    English,
    
} as const;
