import English from "./bots/English";

export default {
    English,
    
} as const;
