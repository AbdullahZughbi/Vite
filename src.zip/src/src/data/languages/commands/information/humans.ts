import English from "./humans/English";

export default {
    English,
    
} as const;
