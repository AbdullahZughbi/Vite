const English = {
    embed: {
        title: "{user.name} Information",
        fields: {
            user: "User",
            user_id: "User ID",
            joined_server_at: "Joined server at",
            joined_server_at_unknown: "Unknown",
            joined_discord_at: "Joined discord at",
            boosting_since: {
                message: "Boosting since",
                yes: "Yes",
                not_boosting: "Not boosting"
            },
            permissions: "Permissions"
        }
    }
};

export default English;
