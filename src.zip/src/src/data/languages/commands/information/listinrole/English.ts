const English = {
    invalid_role: "Invalid Role",
    please_valid_role: "Please provide a valid role mention / role name / role ID",
    footer_text: "Usage: {usage}\nExamples: {examples}",
    role_is_not_valid: "<@&{role.id}> is not a valid role to list of members.",
    everyone_is_not_valid: "{role} is not a valid role to list of members.",
    not_found: "No users list in @{role.name}",
    list_of_users: "List of users in @{role.name}",
    requested_by: "Requested by"
};

export default English;
