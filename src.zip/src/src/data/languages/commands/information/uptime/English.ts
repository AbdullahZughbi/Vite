const English = {
    online: "I'm online for **{duration}**"
};

export default English;
