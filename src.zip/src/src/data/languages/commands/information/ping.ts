import English from "./ping/English";

export default {
    English,
    
} as const;
