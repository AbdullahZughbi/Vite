const English = {
    commands_list: "Commands List",
    requested_by: "Requested by",
    select_a_category: "Select a category",
    get_commands: "Get the list of available {cat} commands",
    invite: "Invite",
    dashboard: "Dashboard",
    subscribe_on_youtube: "Subscribe on YouTube"
};

export default English;
