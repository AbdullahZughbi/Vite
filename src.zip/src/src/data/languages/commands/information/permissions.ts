import English from "./permissions/English";

export default {
    English,
    
} as const;
