import English from "./news/English";

export default {
    English,
    
} as const;
