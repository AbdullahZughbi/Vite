const English = {
    could_not_retrieve: "Could not retrieve your avatar.",
    here: "Here is your avatar.",
    dm_success: "I have sent you a DM with your avatar.",
    dm_error: "I can't send you a DM, please make sure your DMs are open."
};

export default English;
