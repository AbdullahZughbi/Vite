const English = {
    list_of_users: "List of users",
    requested_by: "Requested by"
};

export default English;
