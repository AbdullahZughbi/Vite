import English from "./emojis/English";

export default {
    English,
    
} as const;
