import English from "./listinrole/English";

export default {
    English,
    
} as const;
