const English = {
    verification_level: {
        none: "None",
        low: "Low",
        medium: "Medium",
        high: "High",
        highest: "Highest"
    },
    no_vanity_url: "No vanity URL",
    embed: {
        title: "{guild.name} Information",
        fields: {
            god_premium: {
                message: "GOD Premium",
                true: "true",
                false: "false"
            },
            server_name: "Server Name",
            server_id: "Server ID",
            server_owner: "Server Owner",
            server_owner_unknown: "Unknown Owner",
            vanity_url: "Vanity URL",
            region: "Region",
            members_humans_bots: "Members | Humans | Bots",
            verification_level: "Verification Level",
            categories: "Categories",
            channels: "Channels",
            roles: "Roles",
            boosts_level: "Boosts Level",
            number_of_boosts: "Number Of Boosts",
            created_at: "Created At"
        }
    }
};

export default English;
