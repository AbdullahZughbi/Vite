const English = {
    not_found: "There are no news.",
    date_published: "Date published",
    version: "Version",
    news: "News"
};

export default English;
