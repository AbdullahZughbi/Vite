const English = {
    not_found: "No bots found!",
    list_of_bots: "List of bots",
    requested_by: "Requested by"
};

export default English;
