const English = {
    pinging: "Pinging...",
    N_A: "N/A",
    size: {
        Bytes: "Bytes",
        KB: "KB",
        MB: "MB",
        GB: "GB",
        TB: "TB"
    },
    status: {
        Ready: "Ready",
        Connecting: "Connecting",
        Reconnecting: "Reconnecting",
        Idle: "Idle",
        NearlyReady: "Nearly Ready",
        Disconnected: "Disconnected",
        WaitingForGuilds: "Waiting For Guilds",
        Identifying: "Identifying",
        Resuming: "Resuming",
        Unknown: "Unknown"
    },
    message: {
        pong: "Pong!",
        status: "Status",
        latency: "Latency",
        discord_api: "Discord API",
        database_latency: "Database Latency",
        database_size: "Database Size",
        memory_bot: "Memory (Bot)",
        cpu_usage: "CPU Usage"
    },
    ms: "ms"
};

export default English;
