import English from "./interactionCreate/English";

export default {
    English,
    
} as const;
