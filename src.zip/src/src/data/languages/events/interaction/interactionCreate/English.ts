const English = {
    error: "An error occurred!",
    not_allowed_button: "You are not allowed to do that! Only <@{user.id}> can use these buttons.",
    not_allowed_select_menu: "You are not allowed to do that! Only <@{user.id}> can use these select menu.",
    slash_only_servers: "{fail} This command can only be used in servers."
};

export default English;
