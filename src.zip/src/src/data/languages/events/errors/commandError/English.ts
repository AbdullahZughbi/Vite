const English = {
    unable_connect_database: "{warning} Unable to connect to the database. Please check if the database is running and accessible.",
    report: "Report it here",
    error: "{fail} Hey user! An Error just occured, make sure to report it here {discord}"
};

export default English;
