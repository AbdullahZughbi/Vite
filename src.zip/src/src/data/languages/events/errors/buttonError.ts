import English from "./buttonError/English";

export default {
    English,
    
} as const;
