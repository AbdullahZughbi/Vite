import English from "./fatalError/English";

export default {
    English,
    
} as const;
