const English = {
    error: "{fail} Hey user! An error just occured, make sure to report it here {discord}"
};

export default English;
