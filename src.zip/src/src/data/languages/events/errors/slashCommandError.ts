import English from "./slashCommandError/English";

export default {
    English,
    
} as const;
