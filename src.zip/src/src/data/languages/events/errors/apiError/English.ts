const English = {
    error: "An API Error has occured, make sure to report it here {discord}"
};

export default English;
