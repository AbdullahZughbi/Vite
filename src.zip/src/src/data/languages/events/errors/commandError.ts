import English from "./commandError/English";

export default {
    English,
    
} as const;
