import English from "./apiError/English";

export default {
    English,
    
} as const;
