import English from "./selectMenuError/English";

export default {
    English,
    
} as const;
