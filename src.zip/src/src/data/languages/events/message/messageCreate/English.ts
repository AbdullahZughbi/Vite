const English = {
    hi: "Hi! I'm **GOD**\nTo get started type **{prefix}help**",
    invite: "Invite",
    support: "Support",
    userBlacklist: {
        message: "You are blacklisted{duration}!\n\n{reason}",
        reason: "Reason",
        noReason: "**No reason provided**",
        for: "for"
    },
    guildBlacklist: {
        message: "This server is blacklisted{duration}!\n\n{reason}",
        reason: "Reason",
        noReason: "**No reason provided**",
        for: " for"
    },
    ratelimit: "Please wait <t:{rateLimit}:R> before running the **{cmd}** command again!",
    botPermission: "{fail} I don't have **{missingPermissions}** permissions.\n\n**Need help?**\n{link}",
    userPermission: "You don't have **{missingPermissions}** permissions.",
    disabledCommand: {
        support: "Support",
        message: "Developer(s) have disabled the command for now. Try again Later!\n\nFor updates, click the button below:"
    }
};

export default English;
