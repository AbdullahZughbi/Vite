const English = {
    category_not_found: "Category not found",
    commands: "Commands",
    
};

export default English;
