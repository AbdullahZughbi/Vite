import ExtendedClient from "../structures/ExtendedClient";
import languages from "./languages/data/ButtonMenu";
import type { supportLanguages } from "../database/schemas/Guild";
import {
    EmbedBuilder,
    ButtonBuilder,
    ActionRowBuilder,
    Message,
    TextChannel,
    User,
    MessageComponentInteraction,
    ButtonStyle,
    GuildMember
} from "discord.js";

type ButtonConfig = {
    emoji: string;
    style: ButtonStyle | string;
    customId: string;
};

interface ButtonSet {
    first: ButtonConfig;
    previous: ButtonConfig;
    stop: ButtonConfig;
    next: ButtonConfig;
    last: ButtonConfig;
}

export default class ButtonMenu {
    public language: typeof languages[supportLanguages];
    public client: ExtendedClient;
    public channel: TextChannel;
    public member: GuildMember | User;
    public embed: EmbedBuilder;
    public arr: string[] | null;
    public interval: number;
    public content?: string;
    public button: ButtonSet;
    public timeout: number;
    public json: ReturnType<EmbedBuilder["toJSON"]>;
    public current: number;
    public max: number | null;
    private message!: Message;
    private collector?: ReturnType<Message["createMessageComponentCollector"]>;

    constructor(
        _language: supportLanguages,
        client: ExtendedClient,
        channel: TextChannel,
        member: GuildMember | User,
        embed: EmbedBuilder,
        arr: string[] | null = null,
        interval = 10,
        content?: string,
        button: ButtonSet = {
            first: {
                emoji: "⏪",
                style: "Primary",
                customId: "first"
            },
            previous: {
                emoji: "◀️",
                style: "Primary",
                customId: "previous"
            },
            stop: {
                emoji: "🗑",
                style: "Danger",
                customId: "stop"
            },
            next: {
                emoji: "▶️",
                style: "Primary",
                customId: "next"
            },
            last: {
                emoji: "⏩",
                style: "Primary",
                customId: "last"
            },
        },
        timeout = 180_000
    ) {
        this.language = languages[_language];
        this.client = client;
        this.channel = channel;
        this.member = member;
        this.embed = embed;
        this.arr = arr;
        this.interval = interval;
        this.content = content;
        this.button = button;
        this.timeout = timeout;

        this.json = this.embed.toJSON();

        this.current = 0;
        this.max = this.arr ? this.arr.length : null;

        // Prepare initial embed slice with title and description
        const firstEmbed = new EmbedBuilder(this.json);
        const description = this.arr ? this.arr.slice(this.current, this.interval) : null;
        if (description) {
            firstEmbed
                .setTitle(this.embed.data.title + " " + getRange(this.arr!, this.current, this.interval))
                .setDescription(Array.isArray(description) ? description.join("\n\n") : description);
        }

        // Send initial message with embed and buttons, then create collector for interactions
        this.channel.send(ContentAndEmbed(this.content, firstEmbed, this.addButton()))
            .then(message => {
                this.message = message;
                this.createCollector();
            })
            .catch(console.error);
    }

    /**
     * Create and return an ActionRow with navigation buttons,
     * disabling buttons when at start/end accordingly.
     */
    public addButton(): ActionRowBuilder<ButtonBuilder> {
        const row = new ActionRowBuilder<ButtonBuilder>();

        const buildButton = (cfg: ButtonConfig, disabled = false) =>
            new ButtonBuilder()
                .setEmoji(cfg.emoji)
                .setStyle(cfg.style as ButtonStyle)
                .setCustomId(cfg.customId)
                .setDisabled(disabled);

        // Disable first & previous if on first page
        const firstDisabled = this.current === 0;
        // Disable next & last if on last page
        const lastDisabled = this.max !== null
            ? this.current + this.interval >= this.max
            : true;

        row.addComponents(
            buildButton(this.button.first, firstDisabled),
            buildButton(this.button.previous, firstDisabled),
            buildButton(this.button.stop, false),
            buildButton(this.button.next, lastDisabled),
            buildButton(this.button.last, lastDisabled),
        );

        return row;
    }

    private async createCollector() {
        const filter = (interaction: MessageComponentInteraction) => {
            if (interaction.user.id === this.member.id) return true;

            interaction.reply({
                content: `${this.language.not_allowed.replace(/{member.id}/g, `${this.member.id}`)}`,
                ephemeral: true,
            }).catch(() => {});

            return false;
        };

        this.collector = this.message.createMessageComponentCollector({
            filter,
            time: this.timeout,
        });

        this.collector.on("collect", async (interaction) => {
            // Disable buttons during processing
            const disabledRow = this.addButton();
            disabledRow.components.forEach(button => button.setDisabled(true));

            try {
                await interaction.update({
                    components: [disabledRow]
                });

                let newEmbed: EmbedBuilder | undefined;

                switch (interaction.customId) {
                    case "first":
                        newEmbed = this.first();
                        break;
                    case "previous":
                        newEmbed = this.previous();
                        break;
                    case "stop":
                        this.stop();
                        await interaction.editReply({ components: [] });
                        return;
                    case "next":
                        newEmbed = this.next();
                        break;
                    case "last":
                        newEmbed = this.last();
                        break;
                }

                if (newEmbed) {
                    await interaction.editReply({
                        embeds: [newEmbed],
                        components: [this.addButton()],
                    });
                } else {
                    // If no new embed (e.g. pressing disabled button), just re-enable buttons
                    await interaction.editReply({ components: [this.addButton()] });
                }
            } catch (error) {
                console.error("Error handling button interaction:", error);
            }
        });

        this.collector.on("end", (): void => {
            if (!this.message) return;
            
            const disabledRow = this.addButton();
            disabledRow.components.forEach(btn => btn.setDisabled(true));
            const embed = new EmbedBuilder(this.json)
                .setDescription(`${this.language.interaction_ended}`)
                .setColor("#050000");
            
            if (this.embed.data.footer) {
                embed.setFooter(this.embed.data.footer);
            }
            if (this.embed.data.title) {
                embed.setTitle(this.embed.data.title)
            }
            
            this.message.edit({
                components: [disabledRow],
                embeds: [embed],
            }).catch(() => { });
        });
    }

    public first(): EmbedBuilder | undefined {
        if (this.current === 0) return undefined;
        this.current = 0;

        return new EmbedBuilder(this.json)
            .setTitle(this.embed.data.title + " " + getRange(this.arr!, this.current, this.interval))
            .setDescription(this.arr!.slice(this.current, this.current + this.interval).join("\n\n"))
            .setColor("#050000");
    }

    public previous(): EmbedBuilder | undefined {
        if (this.current === 0) return undefined;
        this.current -= this.interval;

        return new EmbedBuilder(this.json)
            .setTitle(this.embed.data.title + " " + getRange(this.arr!, this.current, this.interval))
            .setDescription(this.arr!.slice(this.current, this.current + this.interval).join("\n\n"))
            .setColor("#050000");
    }

    public next(): EmbedBuilder | undefined {
        if (!this.max) return undefined;
        const cap = this.max - (this.max % this.interval);
        if (this.current === cap || this.current + this.interval >= this.max) return undefined;

        this.current += this.interval;
        if (this.current >= this.max) this.current = cap;

        const max = this.current + this.interval >= this.max ? this.max : this.current + this.interval;

        return new EmbedBuilder(this.json)
            .setTitle(this.embed.data.title + " " + getRange(this.arr!, this.current, this.interval))
            .setDescription(this.arr!.slice(this.current, max).join("\n\n"))
            .setColor("#050000");
    }

    public last(): EmbedBuilder | undefined {
        if (!this.max) return undefined;
        const cap = this.max - (this.max % this.interval);
        if (this.current === cap || this.current + this.interval >= this.max) return undefined;

        this.current = cap;
        if (this.current === this.max) this.current -= this.interval;

        return new EmbedBuilder(this.json)
            .setTitle(this.embed.data.title + " " + getRange(this.arr!, this.current, this.interval))
            .setDescription(this.arr!.slice(this.current, this.max).join("\n\n"))
            .setColor("#050000");
    }

    public stop() {
        this.collector?.stop();
    }
}

function getRange(arr: string[], current: number, interval: number): string {
    const max = arr.length > current + interval ? current + interval : arr.length;
    current += 1;
    return (arr.length === 1 || arr.length === current || interval === 1)
        ? `[${current}]`
        : `[${current} - ${max}]`;
}

function ContentAndEmbed(
    content: string | undefined,
    embed: EmbedBuilder,
    button: ActionRowBuilder<ButtonBuilder>
): {
    content?: string;
    embeds: EmbedBuilder[];
    components: ActionRowBuilder<ButtonBuilder>[]
} {
    if (!button) throw new Error("Button is required");

    if (content) {
        return {
            content,
            embeds: [embed],
            components: [button]
        };
    } else {
        return {
            embeds: [embed],
            components: [button]
        };
    }
}
