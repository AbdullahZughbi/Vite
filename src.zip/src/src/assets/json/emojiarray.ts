import emojis from "emoji.json/emoji-compact.json";

export default emojis;
