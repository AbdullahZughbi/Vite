import {
    Client,
    Collection,
    GatewayIntentBits,
    Partials,
    ActivityType,
    EmbedBuilder,
    Options,
} from "discord.js";
import Util from "./src/structures/Util";
import config from "./config";
import { Sequelize } from "sequelize";
import sequelizeConfig from "./sequelize_config";
import ExtendedClient from "./src/structures/ExtendedClient";
import emoji from "./src/data/emoji";

interface BotOptions {
    prefix?: string;
    [key: string]: any;
}

export default class BotClient extends ExtendedClient {
    constructor(options: BotOptions = {}) {
        super({
            ...options,
            partials: [
                Partials.Message,
                Partials.Channel,
                Partials.Reaction,
                Partials.GuildMember,
                Partials.User,
                Partials.GuildScheduledEvent,
                Partials.ThreadMember,
            ],
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMembers,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.GuildEmojisAndStickers,
                GatewayIntentBits.GuildMessageReactions,
                GatewayIntentBits.MessageContent,
                GatewayIntentBits.GuildBans,
                GatewayIntentBits.GuildMessageReactions,
                GatewayIntentBits.GuildMessagePolls,
                GatewayIntentBits.GuildModeration,
            ],
            allowedMentions: {
                parse: ["roles", "users", "everyone"],
                repliedUser: true,
            },
            presence: {
                // status: "online",
                activities: [
                    {
                        type: ActivityType.Playing,
                        name: config.status_name,
                    },
                ],
            },
            makeCache: Options.cacheWithLimits({
                MessageManager: 0,
                PresenceManager: 0,
                ReactionManager: 0,
            })
        });

        const sequelize: Sequelize = new Sequelize(
            sequelizeConfig.DB,
            sequelizeConfig.USER,
            sequelizeConfig.PASSWORD,
            {
                host: sequelizeConfig.HOST,
                dialect: sequelizeConfig.dialect,
                // operationsAliases: sequelizeConfig.operationsAliases,
                dialectOptions: sequelizeConfig.dialectOptions,
                pool: sequelizeConfig.pool,
                logging: sequelizeConfig.logging,
            }
        );

        this.validate(options);
        this.commands = new Collection();
        this.slashcommands = new Collection();
        this.aliases = new Collection();
        this.buttons = new Collection();
        this.selectmenus = new Collection();
        this.modals = new Collection();
        this.events = new Collection();
        this.utils = new Util(this);
        this.config = config;
        this.sequelize = sequelize;
    }

    private validate(options: BotOptions): void {
        if (typeof options !== "object")
            throw new TypeError("Options should be a type of Object.");

        if (!options.prefix) {
            throw new Error("You must pass a prefix for the client.");
        }

        if (typeof options.prefix !== "string") {
            throw new TypeError("Prefix should be a type of String.");
        }

        this.prefix = options.prefix;
    }

    public async start(token: string = "none"): Promise<void> {
        await this.utils.loadDatabases();
        await this.utils.loadCommands();
        await this.utils.loadSlashCommands();
        await this.utils.loadEvents();
        await this.utils.loadButtons();
        await this.utils.loadModals();
        await this.utils.loadSelectMenus();
        // await this.utils.loadContextMenuCommands();

        await this.login(token);
    }
};
