// types/csv.d.ts
declare module "*.csv" {
    // You can customize this interface based on your CSV headers
    interface CSVRow {
        [columnName: string]: string; // all CSV values are parsed as strings
    }
    
    const value: CSVRow[]; // array of parsed rows
    export default value;
}
