// types/require_image.d.ts

declare module "*.png" {
    const image: {
        buffer: () => Buffer;
        base64: () => string;
        dataUrl: () => string;
    };
    export default image;
}

declare module "*.jpg" {
    const image: {
        buffer: () => Buffer;
        base64: () => string;
        dataUrl: () => string;
    };
    export default image;
}

declare module "*.jpeg" {
    const image: {
        buffer: () => Buffer;
        base64: () => string;
        dataUrl: () => string;
    };
    export default image;
}

declare module "*.gif" {
    const image: {
        buffer: () => Buffer;
        base64: () => string;
        dataUrl: () => string;
    };
    export default image;
}
