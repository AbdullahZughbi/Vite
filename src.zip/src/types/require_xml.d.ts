declare module "*.xml" {
    const value: any;
    export default value;
}
