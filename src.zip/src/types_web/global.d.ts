import * as jQuery from "jquery";
import "select2";

declare global {
  const $: typeof jQuery;
  interface Window {
    $: typeof jQuery;
    jQuery: typeof jQuery;
  }
}

export {};
